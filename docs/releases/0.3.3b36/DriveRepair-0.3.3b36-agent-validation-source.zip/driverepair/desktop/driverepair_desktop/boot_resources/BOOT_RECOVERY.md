# Recovering a failed system / boot drive

**Important:** The repository includes experimental BIOS/UEFI source, but no validated, universally bootable DriveRepair recovery image. A booted program that prints a success message does not prove it can enumerate or rescue NVMe/SATA/USB disks safely.

## Supported fallback using an independently trusted live environment

1. On a separate clean PC, prepare a trusted and verified Linux live USB from a maintained distribution. Follow the distribution's checksum/signature verification, not a homemade unsigned image.
2. Boot the affected computer without mounting or repairing the failing system volume. If the drive is physically noisy/unstable, avoid retries and consult a specialist.
3. Connect enough healthy destination space for an image; preferably a separate physical drive. Do not attempt to 'repair the only copy' by rewriting every sector.
4. Run the validated diagnostic/read-only commands from a mounted DriveRepair portable source environment, or a known recovery program. The current direct-physical `rescue-external` workflow is Linux experimental and verifies source/destination ancestry. If unable to confirm safe destination, use a separately validated imaging tool.
5. Preserve rescue maps and hash manifests off the patient. Analyze/repair a *copy* after acquisition.
6. Restore verified recovered files or a known-good system backup to replacement media. Reinstall the OS when needed.

Encryption: BitLocker, FileVault and LUKS require authorized credentials/keys; raw carving encrypted data usually yields false results. Secure Boot, RAID, vendor recovery partitions, BitLocker TPM binding and filesystem support must be tested individually.

## Experimental hybrid live-ISO build recipe (NOT BOOT-VERIFIED)

`./scripts/build_live_iso.sh /build/output` targets Debian trixie on x86-64
with GRUB-PC and GRUB-EFI via live-build. The package includes DriveRepair,
Python/Tk, smartctl, GNU ddrescue, testdisk and network mount tools.
The builder itself never writes USB or patient media. The separate Qt
**Flash bootable USB** workflow can copy a previously built ISO-hybrid to a
specifically selected, sacrificial USB drive after typed erasure confirmation;
all its partitions and files are destroyed. It verifies the ISO bytes by
readback but cannot establish actual bootability. The ISO output is explicitly
`UNVERIFIED` until BIOS and UEFI VM and hardware boot tests pass. The
separately included bare-metal Rust boot code is NOT an established recovery OS.

See `ONE_DRIVE_RECOVERY.md` for the guided live-mode internal disk imaging
workflow, explicit source identity, NAS/USB destination, resume, and limitations.

## Future native boot goals (NOT IMPLEMENTED)

- Reproducible UEFI and BIOS media build with SHA-256 and verified boot smoke tests.
- Built-in OS storage drivers for NVMe, SATA, USB/UASP and SAS; no proprietary firmware bypass by default.
- Explicit no-automount, no-write environment, source/destination physical identity, USB disconnect handling.
- On-device manual recovery journal, encrypted report export and clear recovery/repair separation.

The experimental flasher is available for operator-controlled sacrificial USB
validation, not as a boot-certified recovery product. Never flash a patient disk.
See `USB_FLASH_HARDWARE_QA_20261118.md` before distribution.

## RAM and CPU diagnostics in the live ISO

The new Debian live-build recipe explicitly requests a **Memtest86+** boot menu entry (BIOS/UEFI support must be tested on actual firmware). This independent memory test runs before Linux and is the preferred option for comprehensive RAM checks.

Inside the Linux live desktop, **Hardware Diagnostics (CPU / RAM)** opens a guided terminal launcher. Optional two-minute CPU and bounded-memory tests use Debian `stress-ng`, with no patient disk I/O. They are not a substitute for Memtest86+, do not certify error-free hardware, and cannot repair faulty processors or RAM. `stressapptest` is packaged for specialists. Stop tests if temperature or stability deteriorates.

These capabilities are only **configured in the build recipe** until a real ISO has been built and BIOS/UEFI boot and menu entries validated.

## DriveRepair live menu and login (next build; unverified)

A rebuilt ISO now provides a DriveRepair-specific GRUB menu for **normal graphical
boot (first choice)**, **compatibility graphics (`nomodeset`)**, and a **text-only
diagnostic console**. The XFCE live desktop is configured to autologin as
`driverepair` and autostart the DriveRepair Qt workstation. If graphical
autologin fails, the Debian Live fallback should be **username `driverepair`,
password `live`**, pending real BIOS/UEFI login testing. The built image includes
`/usr/share/driverepair/START_HERE.txt`; the recipe has no OS installer option.

The ISO remains **UNVERIFIED** until real VM and physical-USB tests prove the
bootloader, display, keyboard, desktop session, DriveRepair launch, and read-only
device enumeration. Secure Boot is **not validated**. A GUI boot test on an HP
laptop must record the failing stage before declaring compatibility.
