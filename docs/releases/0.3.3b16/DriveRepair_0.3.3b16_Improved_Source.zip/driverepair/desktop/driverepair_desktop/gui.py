"""DriveRepair Recovery Workstation — modern, low-overhead desktop presentation.

Recovery I/O stays in the CLI engine. This GUI only renders throttled progress
events (~10 Hz max) and never opens patient devices itself. Cross-platform via
stdlib Tk (Windows / macOS / Linux). Visual language: industrial dark console —
not DOS blue, not marketing purple.
"""
from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path

from .rescue_display import RescueDisplayState, format_duration
from .console_ui import fmt_bytes
from .preferences import load_preferences, save_preferences
from .media_profiles import identify_profile
from .release_policy import PUBLIC_BETA_IMAGE_ONLY, IN_PLACE_WRITE_COMMANDS


# Industrial dark palette (high-contrast status colors, no purple/glow stack).
C = {
    "bg": "#0c1420",
    "panel": "#142133",
    "panel2": "#1b2b40",
    "border": "#293c51",
    "text": "#eff5fb",
    "muted": "#aebfd0",
    "accent": "#40cfb5",
    "ok": "#35b99c",
    "warn": "#e6b45b",
    "fail": "#f07e87",
    "slow": "#e6a75b",
    "pending": "#24374a",
    "current": "#66c8ff",
}


def recovery_command(args: list[str], *, executable: str | None = None,
                     entrypoint: str | None = None) -> list[str]:
    """Launch the same recovery engine when installed or running as a zipapp.

    `python -m driverepair_desktop` does not resolve the package from a .pyz
    archive in a fresh interpreter. The portable GUI must re-enter its .pyz.
    """
    python = executable or sys.executable
    entry = entrypoint if entrypoint is not None else sys.argv[0]
    if entry.lower().endswith('.pyz') and os.path.isfile(entry):
        return [python, os.path.abspath(entry), *args]
    return [python, '-m', 'driverepair_desktop', *args]


# Centralize the child control contract across both Tk and CLI. The GUI must
# never use process termination as a shortcut around a patient write boundary.
PROGRESS_OPERATIONS = frozenset({
    'rescue-image', 'rescue-external', 'rescue-system',
    'scan', 'scan-image', 'care-image', 'care-external',
    'refresh-image', 'refresh-external', 'refresh-system',
    'benchmark-external', 'last-resort-system-refresh',
})
COOPERATIVE_STOP_OPERATIONS = frozenset({
    'scan', 'scan-image', 'care-image', 'care-external',
    'refresh-image', 'refresh-external', 'refresh-system',
})
POTENTIALLY_WRITING_OPERATIONS = frozenset({
    'care-image', 'care-external', 'refresh-image', 'refresh-external',
    'refresh-system', 'last-resort-system-refresh',
})


def prepare_child_arguments(args: list[str]) -> list[str]:
    """Pass the stop protocol only to child commands which implement it."""
    result = list(args)
    if result and result[0] in PROGRESS_OPERATIONS and '--progress-jsonl' not in result:
        result.extend(['--progress-jsonl', '--no-live-dashboard'])
    if result and result[0] in COOPERATIVE_STOP_OPERATIONS and '--cooperative-stop-stdin' not in result:
        result.append('--cooperative-stop-stdin')
    return result


def _gui_debug_enabled() -> bool:
    return os.environ.get('DRIVEREPAIR_GUI_DEBUG', '').strip().lower() in {'1', 'true', 'yes', 'on'}


def _restrict_debug_log_access(path: Path) -> None:
    """Best-effort local privacy for opt-in debug logs.

    POSIX: chmod 0o600. Windows: ACL tightening is not claimed here; operators
    should set DRIVEREPAIR_GUI_DEBUG_LOG to a private directory when needed.
    """
    try:
        if os.name == 'posix':
            os.chmod(path, 0o600)
            if path.parent.exists():
                os.chmod(path.parent, 0o700)
    except OSError:
        pass


def _open_gui_debug_log() -> Path | None:
    """Mirror UI/engine diagnostics to a local file when debug tracking is on.

    Prefer an explicit path via DRIVEREPAIR_GUI_DEBUG_LOG; otherwise a per-user
    temp directory. Never fall back to a hard-coded lab path.
    """
    if not _gui_debug_enabled():
        return None
    import faulthandler
    import tempfile
    faulthandler.enable(all_threads=True)
    stamp = time.strftime('%Y%m%dT%H%M%S')
    candidates = [
        Path(os.environ['DRIVEREPAIR_GUI_DEBUG_LOG']) if os.environ.get('DRIVEREPAIR_GUI_DEBUG_LOG') else None,
        Path(tempfile.gettempdir()) / 'DriveRepair' / 'debug' / f'gui_debug_{stamp}.log',
    ]
    for path in candidates:
        if path is None:
            continue
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('a', encoding='utf-8') as handle:
                handle.write(
                    f'# DriveRepair GUI debug start {time.strftime("%Y-%m-%dT%H:%M:%S")}\n'
                    f'# pid={os.getpid()} python={sys.executable}\n'
                    f'# argv={sys.argv!r}\n'
                    f'# retention=operator-managed local file; unset DRIVEREPAIR_GUI_DEBUG to stop\n'
                )
            _restrict_debug_log_access(path)
            latest = path.with_name('gui_debug_latest.log')
            try:
                latest.write_text(f'active={path}\n', encoding='utf-8')
                _restrict_debug_log_access(latest)
            except OSError:
                pass
            print(f'[DriveRepair DEBUG] logging to {path}', flush=True)
            return path
        except OSError:
            continue
    return None


def launch() -> None:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, simpledialog, ttk
    except ImportError as exc:
        raise RuntimeError("Tk is unavailable. Install the OS Python tkinter package") from exc

    try:
        root = tk.Tk()
    except tk.TclError as exc:
        raise RuntimeError("No desktop display available. Use the DriveRepair CLI instead") from exc

    debug_log_path = _open_gui_debug_log()
    debug_lock = threading.Lock()

    def debug_trace(text: str) -> None:
        if debug_log_path is None:
            return
        line = text if text.endswith('\n') else text + '\n'
        try:
            with debug_lock:
                with debug_log_path.open('a', encoding='utf-8') as handle:
                    handle.write(line)
            print(line, end='', flush=True)
        except OSError:
            pass

    window_title = "DriveRepair Recovery Workstation"
    if debug_log_path is not None:
        window_title += " [DEBUG]"
        debug_trace(f'debug_log={debug_log_path}\n')
    root.title(window_title)
    root.geometry("1180x820")
    root.minsize(960, 700)
    root.configure(bg=C["bg"])

    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    style.configure(".", background=C["bg"], foreground=C["text"], fieldbackground=C["panel2"])
    style.configure("TFrame", background=C["bg"])
    style.configure("Card.TFrame", background=C["panel"])
    style.configure("TLabel", background=C["bg"], foreground=C["text"])
    style.configure("Muted.TLabel", background=C["bg"], foreground=C["muted"])
    style.configure("Card.TLabel", background=C["panel"], foreground=C["text"])
    style.configure("Title.TLabel", background=C["bg"], foreground=C["text"], font=("Segoe UI", 22, "bold"))
    style.configure("TButton", background=C["panel2"], foreground=C["text"], padding=6)
    style.map("TButton", background=[("active", C["border"])])
    style.configure("Accent.TButton", background=C["accent"], foreground="#061018")
    style.configure("TNotebook", background=C["bg"], borderwidth=0)
    style.configure("TNotebook.Tab", background=C["panel2"], foreground=C["muted"], padding=(14, 8))
    style.map("TNotebook.Tab", background=[("selected", C["panel"])], foreground=[("selected", C["text"])])
    style.configure("Treeview", background=C["panel2"], fieldbackground=C["panel2"],
                    foreground=C["text"], borderwidth=0, rowheight=26)
    style.configure("Treeview.Heading", background=C["panel"], foreground=C["muted"])
    style.configure("Horizontal.TProgressbar", troughcolor=C["panel2"], background=C["accent"])
    style.configure('Wide.Vertical.TScrollbar', width=24, arrowsize=22,
                    background=C['panel2'], troughcolor=C['bg'])

    prefs = load_preferences()
    q: queue.Queue[tuple[str, object]] = queue.Queue()
    process: subprocess.Popen[str] | None = None
    busy = False
    staged_job = None  # Workflow selection NEVER starts disk I/O.
    active_command: list[str] = []  # The actual current child operation.
    map_width, map_height = 64, 12
    rescue_metrics = RescueDisplayState()
    map_cells = ["."] * (map_width * map_height)
    map_dirty = True
    last_map_draw = 0.0
    stats = {
        "phase": "IDLE",
        "pct": 0.0,
        "offset": 0,
        "size": 0,
        "latency_ms": None,
        "median_ms": None,
        "rewritten": 0,
        "verified": 0,
        "message": "Ready",
        "health": {"media": "UNKNOWN", "transport": "UNKNOWN", "mechanical": "UNKNOWN"},
        "started": None,
    }

    selected = tk.StringVar(value="No external drive selected")
    inventory = {}  # Snapshot used only for DISPLAY; CLI rediscovers and verifies before writes.
    image = tk.StringVar()
    dest_file = tk.StringVar()
    dest_dir = tk.StringVar()
    integrity_manifest = tk.StringVar()
    integrity_reference = tk.StringVar()
    integrity_output = tk.StringVar()
    integrity_summary = tk.StringVar(value="No integrity check run. Readable bytes are NOT necessarily correct bytes.")
    journal_dir = tk.StringVar(value=str(Path.home() / "DriveRepairJournal"))
    status = tk.StringVar(value="Ready — choose a workflow, review settings, then select Start job")
    prerequisite_text = tk.StringVar(value='Checking optional drive-health tools…')
    phase_var = tk.StringVar(value="IDLE")
    health_var = tk.StringVar(value="Drive health: not checked yet · Select a disk and run SMART")
    metric_var = tk.StringVar(value="—")
    msg_var = tk.StringVar(value="Select a workflow. Disk I/O runs in a child process.")
    recovered_var = tk.StringVar(value="—")
    errors_var = tk.StringVar(value="—")
    speed_var = tk.StringVar(value="—")
    eta_var = tk.StringVar(value="—")
    destination_var = tk.StringVar(value="Destination: not selected")
    capacity_var = tk.StringVar(value="Free space: not checked")
    warning_var = tk.StringVar(value="Progress is from committed recovery state; unscanned media stays unknown.")
    advanced_open = tk.BooleanVar(value=False)
    expert_settings = tk.BooleanVar(value=False)
    last_result: dict | None = None

    shell = ttk.Frame(root, padding=16)
    shell.pack(fill="both", expand=True)

    header = ttk.Frame(shell)
    header.pack(fill="x")
    ttk.Label(header, text="DriveRepair", style="Title.TLabel").pack(side="left")
    ttk.Label(header, text="  Recovery Workstation", style="Muted.TLabel").pack(side="left", pady=(10, 0))
    ttk.Label(header, text="Privacy-first · Recovery evidence · Cross-platform",
              style="Muted.TLabel").pack(side="right", pady=(12, 0))

    # Startup local prerequisite check. No network, package install, or elevation
    # happens without explicit user action.
    prereq_row = ttk.Frame(shell)
    prereq_row.pack(fill='x', pady=(3, 0))
    ttk.Label(prereq_row, textvariable=prerequisite_text, style='Muted.TLabel').pack(side='left')
    prereq_install = ttk.Button(prereq_row, text='Install SMART tools', state='disabled')
    # Shown only when an optional dependency is missing.

    # Keep a large, live dashboard during recovery, but do not fill the
    # Start Here screen with empty telemetry before a job exists.
    # Do not pack overview initially — packing then immediately forgetting races
    # idle-layout tests and flashes empty telemetry on slow Windows Tk updates.
    overview = ttk.Frame(shell)
    dashboard_visible = tk.BooleanVar(value=bool(prefs["dashboard"]))

    # Live ops strip
    ops = tk.Frame(overview, bg=C["panel"], highlightbackground=C["border"], highlightthickness=1)
    ops.pack(fill="x", pady=(14, 10), ipady=8, ipadx=8)
    left = tk.Frame(ops, bg=C["panel"])
    left.pack(side="left", fill="both", expand=True, padx=10, pady=6)
    tk.Label(left, textvariable=phase_var, bg=C["panel"], fg=C["accent"],
             font=("Segoe UI Semibold", 14)).pack(anchor="w")
    tk.Label(left, textvariable=msg_var, bg=C["panel"], fg=C["text"],
             font=("Segoe UI", 10)).pack(anchor="w", pady=(2, 0))
    tk.Label(left, textvariable=health_var, bg=C["panel"], fg=C["muted"],
             font=("Segoe UI", 9)).pack(anchor="w", pady=(4, 0))
    right = tk.Frame(ops, bg=C["panel"])
    right.pack(side="right", padx=10, pady=6)
    tk.Label(right, textvariable=metric_var, bg=C["panel"], fg=C["text"],
             font=("Consolas", 11), justify="right").pack(anchor="e")
    # The progress bar is outside the pack-managed left/right strip so it spans
    # the actual window width (not the tiny gap left between side panels).
    pbar = ttk.Progressbar(overview, mode="determinate", maximum=1000)
    pbar.pack(fill="x", pady=(0, 8))

    # Rescue overview: always visible while navigating across workflow tabs.
    summary = tk.Frame(overview, bg=C["bg"])
    summary.pack(fill="x", pady=(0, 8))
    summary_labels = []
    for label, variable in (("DATA SAVED TO IMAGE", recovered_var),
                            ("UNREADABLE / UNKNOWN", errors_var),
                            ("CURRENT SPEED", speed_var), ("TIME REMAINING", eta_var)):
        card = tk.Frame(summary, bg=C["panel"], highlightbackground=C["border"], highlightthickness=1)
        card.pack(side="left", fill="both", expand=True, padx=3)
        heading = tk.Label(card, text=label, bg=C["panel"], fg=C["muted"],
                           font=("Segoe UI", 8))
        heading.pack(anchor="w", padx=10, pady=(8, 0))
        summary_labels.append(heading)
        tk.Label(card, textvariable=variable, bg=C["panel"], fg=C["text"],
                 font=("Segoe UI", 15, "bold")).pack(anchor="w", padx=10, pady=(2, 8))
    dest_line = tk.Frame(overview, bg=C["bg"])
    dest_line.pack(fill="x", pady=(0, 6))
    tk.Label(dest_line, textvariable=destination_var, bg=C["bg"], fg=C["muted"],
             font=("Segoe UI", 9), anchor="w").pack(side="left", fill="x", expand=True)
    tk.Label(dest_line, textvariable=capacity_var, bg=C["bg"], fg=C["muted"],
             font=("Segoe UI", 9)).pack(side="right")
    warning_label = tk.Label(overview, textvariable=warning_var, anchor="w", bg=C["panel"],
                             fg=C["muted"], font=("Segoe UI", 9), padx=10, pady=5,
                             wraplength=1090, justify='left')
    warning_label.pack(fill="x", pady=(0, 8))

    # Sector map
    map_frame = tk.Frame(overview, bg=C["panel"], highlightbackground=C["border"], highlightthickness=1)
    map_frame.pack(fill="both", expand=False, pady=(0, 10))
    legend_var = tk.StringVar(value="Activity map  ·  . unscanned   o read to image   ? in progress   X unreadable/failed")
    tk.Label(map_frame, textvariable=legend_var,
             bg=C["panel"], fg=C["muted"], font=("Segoe UI", 9)).pack(anchor="w", padx=10, pady=(8, 2))
    # The map shows COLORS, not glyphs. Use explicit colored swatches and plain
    # language so users never have to guess what S/o/X corresponds to.
    legend_row = tk.Frame(map_frame, bg=C['panel'])
    legend_row.pack(anchor='w', fill='x', padx=10, pady=(0, 5))
    for symbol, caption in [('.', 'Not scanned'), ('o', 'Read successfully'),
                            ('?', 'In progress'), ('S', 'Slow region'),
                            ('!', 'Needs investigation'), ('X', 'Read error / unknown')]:
        item = tk.Frame(legend_row, bg=C['panel'])
        item.pack(side='left', padx=(0, 14))
        tk.Label(item, bg={
            '.': C['pending'], 'o': C['ok'], '?': C['current'],
            'S': C['slow'], '!': C['warn'], 'X': C['fail']
        }[symbol], width=2, height=1).pack(side='left', padx=(0, 4))
        tk.Label(item, text=caption, bg=C['panel'], fg=C['muted'],
                 font=('Segoe UI', 8)).pack(side='left')
    canvas = tk.Canvas(map_frame, height=88, bg=C["panel2"], highlightthickness=0)
    canvas.pack(fill="x", padx=10, pady=(0, 10))

    color_for = {".": C["pending"], "o": C["ok"], "?": C["current"],
                 "S": C["slow"], "!": C["warn"], "X": C["fail"]}

    def redraw_map(force: bool = False) -> None:
        nonlocal map_dirty, last_map_draw
        now = time.monotonic()
        if not force and (not map_dirty or now - last_map_draw < 0.15):
            return
        map_dirty = False
        last_map_draw = now
        canvas.delete("all")
        w = max(canvas.winfo_width(), 40)
        h = max(canvas.winfo_height(), 40)
        cw, ch = w / map_width, h / map_height
        for y in range(map_height):
            for x in range(map_width):
                sym = map_cells[y * map_width + x]
                canvas.create_rectangle(
                    x * cw, y * ch, (x + 1) * cw - 1, (y + 1) * ch - 1,
                    fill=color_for.get(sym, C["pending"]), outline="",
                )

    def mark_map(offset: int, size: int, symbol: str, length: int = 0) -> None:
        nonlocal map_dirty
        if size <= 0:
            return
        # A full read spans a RANGE, not one pixel. Mark every map cell whose
        # range intersects the read; samples still leave the rest unknown.
        offset = min(max(0, int(offset)), size - 1)
        end = min(size, offset + max(1, int(length)))
        first = min(len(map_cells) - 1, offset * len(map_cells) // size)
        last = min(len(map_cells) - 1, max(0, end - 1) * len(map_cells) // size)
        rank = {".": 0, "o": 1, "?": 1, "S": 2, "!": 3, "X": 4}
        for idx in range(first, last + 1):
            if rank.get(symbol, 0) >= rank.get(map_cells[idx], 0):
                map_cells[idx] = symbol
                map_dirty = True

    def reset_map() -> None:
        nonlocal map_dirty
        for i in range(len(map_cells)):
            map_cells[i] = "."
        map_dirty = True
        redraw_map(force=True)

    notebook = ttk.Notebook(shell)
    notebook.pack(fill="both", expand=True)
    # Every workflow page is independently scrollable. Otherwise on a typical
    # laptop the lower controls (including Start/Restore) can be unreachable.
    tab_canvases = {}
    workflow_pages = {}
    def workflow_tab(name: str, title: str):
        container = ttk.Frame(notebook)
        scroller = tk.Canvas(container, bg=C['bg'], highlightthickness=0, borderwidth=0)
        scrollbar = ttk.Scrollbar(container, orient='vertical', command=scroller.yview,
                                  style='Wide.Vertical.TScrollbar')
        scroller.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        scroller.pack(side='left', fill='both', expand=True)
        page = ttk.Frame(scroller, padding=12)
        window_id = scroller.create_window((0, 0), window=page, anchor='nw')
        page.bind('<Configure>', lambda e: scroller.configure(scrollregion=scroller.bbox('all')))
        scroller.bind('<Configure>', lambda e: scroller.itemconfigure(window_id, width=e.width))
        notebook.add(container, text=title)
        workflow_pages[name] = container  # Notebook owns the CONTAINER, not the page frame.
        tab_canvases[name] = scroller
        return page

    def scroll_active_page(event):
        # Avoid scrolling the recovery log or inventory while pointer is outside
        # the notebook. Windows events use delta=120 per notch; X11 uses buttons.
        if not notebook.winfo_ismapped():
            return
        under = root.winfo_containing(root.winfo_pointerx(), root.winfo_pointery())
        if under is None:
            return
        active = root.nametowidget(notebook.select())
        current = under
        while current is not None and current is not root:
            if current is active:
                steps = -int(event.delta / 120) if getattr(event, 'delta', 0) else 0
                if steps == 0:
                    steps = -1 if getattr(event, 'num', 0) == 4 else 1
                for canvas_item in tab_canvases.values():
                    if str(canvas_item.master) == str(active):
                        canvas_item.yview_scroll(steps, 'units')
                        return 'break'
            current = getattr(current, 'master', None)
    root.bind_all('<MouseWheel>', scroll_active_page, add='+')
    root.bind_all('<Button-4>', scroll_active_page, add='+')
    root.bind_all('<Button-5>', scroll_active_page, add='+')

    tab_start = workflow_tab('start', ' Start here ')
    tab_drive = workflow_tab('drive', ' Diagnose / Rescue ')
    tab_system = workflow_tab('system', ' Recover OS drive ')
    tab_image = workflow_tab('image', ' Image recovery ')
    tab_integrity = workflow_tab('integrity', ' Integrity / bit errors ')
    tab_undelete = workflow_tab('undelete', ' Recover deleted files ')
    tab_refresh = workflow_tab('refresh', ' In-place refresh ')
    tab_fs = workflow_tab('filesystem', ' Clone repair ')

    # Plain-language landing page; advanced controls remain accessible.
    # Guided workflows: no unnecessary expertise or hidden destructive defaults.
    ttk.Label(tab_start, text='What would you like to do?',
              font=('Segoe UI', 16, 'bold')).pack(anchor='w', pady=(4, 12))
    ttk.Label(tab_start, text='Choose a goal. DriveRepair separates data rescue from media repair. '
              'All recovery output should go to healthy storage, never the failing disk.',
              style='Muted.TLabel', wraplength=880).pack(anchor='w', pady=(0, 14))
    workflow_cards = [
        ('My computer will not boot / only one internal disk',
         'Boot a trusted live USB, then rescue to a separate disk or NAS share.', 'system'),
        ('My files were accidentally deleted',
         'Preview deleted file metadata and restore only files I select. Start from an image.', 'undelete'),
        ('My external drive is slow or failing',
         'Find the device by model, capacity and identity; run fast triage or rescue.', 'drive'),
        ('I need a forensic working copy',
         'Rescue an image, verify bytes, preserve original evidence and recovery maps.', 'image'),
        ('I suspect silent file corruption / flipped bits',
         'Compare image chunks against a previously trusted baseline; recover only provably correct regions.', 'integrity'),
        ('My filesystem is corrupted',
         'Check and repair a NEW filesystem image copy; original stays unchanged.', 'filesystem'),
        ('I want to refresh readable media',
         'Expert-only experimental original-media writes. Not a replacement for a backup.', 'refresh'),
    ]
    def choose_workflow(name: str) -> None:
        """Navigate to the notebook-managed page; do not select its canvas child."""
        notebook.select(workflow_pages[name])
        tab_canvases[name].yview_moveto(0)
        status.set(f"Selected workflow: {notebook.tab(workflow_pages[name], 'text').strip()}")

    for heading, explanation, target in workflow_cards:
        card = ttk.Frame(tab_start, style='Card.TFrame', padding=(12, 9))
        card.pack(fill='x', pady=4)
        ttk.Button(card, text=heading, command=lambda t=target: choose_workflow(t)).pack(side='left', padx=(0, 14))
        ttk.Label(card, text=explanation, style='Card.TLabel', wraplength=535).pack(side='left')
    ttk.Label(tab_start, text='Boot/system disk unusable? Start from an independently trusted live USB '
              'environment. The custom boot components are experimental, not validated recovery media.',
              style='Muted.TLabel', wraplength=850).pack(anchor='w', pady=14)

    def set_dashboard_visible(visible: bool) -> None:
        dashboard_visible.set(bool(visible))
        if visible:
            if not overview.winfo_manager():
                overview.pack(fill='x', before=notebook)
            overview.update_idletasks()
        else:
            overview.pack_forget()

    def on_dashboard_toggle() -> None:
        set_dashboard_visible(bool(dashboard_visible.get()))
        save_repair_preferences()

    ttk.Checkbutton(header, text='Show recovery dashboard', variable=dashboard_visible,
                    command=on_dashboard_toggle).pack(
                        side='right', padx=(0, 14), pady=(10, 0))

    log_controls = ttk.Frame(shell)
    log_controls.pack(fill='x', pady=(8, 0))
    ttk.Checkbutton(log_controls, text='Advanced details / engine log', variable=advanced_open,
                    command=lambda: show_advanced()).pack(anchor='w')
    log_holder = tk.Frame(shell, bg=C["panel"], highlightbackground=C["border"], highlightthickness=1)
    tk.Label(log_holder, text="Operation log", bg=C["panel"], fg=C["muted"],
             font=("Segoe UI", 9)).pack(anchor="w", padx=8, pady=(6, 0))
    log = tk.Text(log_holder, height=6, wrap="word", state="disabled",
                  bg=C["panel2"], fg=C["text"], insertbackground=C["text"],
                  font=("Consolas", 9), relief="flat", borderwidth=0)
    log.pack(fill="both", expand=True, padx=8, pady=6)

    def show_advanced() -> None:
        if advanced_open.get():
            log_holder.pack(side='bottom', fill='both', expand=False, pady=(5, 0), before=log_controls)
        else:
            log_holder.pack_forget()

    def write(text: str) -> None:
        log.configure(state="normal")
        log.insert("end", text)
        # Keep a bounded log buffer: GUI memory must not grow over multi-day rescues.
        if int(log.index('end-1c').split('.')[0]) > 2500:
            log.delete('1.0', '500.0')
        if advanced_open.get():
            log.see("end")
        log.configure(state="disabled")
        debug_trace(text)

    def require(var: tk.StringVar, name: str) -> str:
        value = var.get().strip()
        if not value:
            raise ValueError(f"Select a {name} first.")
        return value

    def row(parent, title: str, var: tk.StringVar, picker=None) -> None:
        line = ttk.Frame(parent)
        line.pack(fill="x", pady=4)
        ttk.Label(line, text=title, width=22).pack(side="left")
        ttk.Entry(line, textvariable=var).pack(side="left", fill="x", expand=True, padx=4)
        if picker:
            ttk.Button(line, text="Browse…", command=picker).pack(side="left")

    def pick_file():
        chosen = filedialog.askopenfilename(title="Select source image / archive")
        if chosen:
            image.set(chosen)

    def pick_output():
        chosen = filedialog.asksaveasfilename(title="Choose a NEW destination image",
                                              defaultextension=".img")
        if chosen:
            dest_file.set(chosen)

    def pick_dir():
        chosen = filedialog.askdirectory(title="Choose parent folder for recovered files")
        if chosen:
            dest_dir.set(os.path.join(chosen, "recovered_files"))

    def pick_journal():
        chosen = filedialog.askdirectory(title="Choose a healthy, separate parent disk for journal")
        if chosen:
            journal_dir.set(os.path.join(chosen, "driverepair-journal-new"))

    def apply_rescue(event: dict) -> None:
        view = rescue_metrics.update(event)
        phase = str(view.get('phase', 'FORWARD'))
        total = int(view.get('total_bytes') or 0)
        processed = int(view.get('processed_bytes') or 0)
        recovered = int(view.get('recovered_bytes') or 0)
        missing = int(view.get('unreadable_bytes') or 0)
        phase_var.set('RETRYING UNREADABLE REGIONS' if phase == 'RETRY' else 'RECOVERING IMAGE')
        pct = view['percent']
        pbar['value'] = max(0, min(1000, int(pct * 10)))
        msg_var.set(f'{pct:.2f}% of first pass processed · {fmt_bytes(processed)} / {fmt_bytes(total)}'
                    if total else 'Preparing recovery')
        recovered_var.set(fmt_bytes(recovered))
        errors_var.set(f'{fmt_bytes(missing)}  ·  {view.get("missing_regions", 0)} region(s)')
        speed = view['speed_bytes_per_sec']
        speed_var.set(f'{fmt_bytes(int(speed))}/s' if speed else 'Measuring…')
        eta_var.set(format_duration(view['eta_seconds']) if view['eta_seconds'] is not None
                    else ('Retry pass (unknown)' if phase == 'RETRY' else 'Calculating…'))
        metric_var.set(f'{pct:.1f}%  ·  {view.get("failed_reads", 0)} read failures')
        health_var.set('Data saved = OS reads committed to image; not verified against original hashes.')
        legend_var.set('Recovery map · . unscanned   o read to image   ? partial   X unreadable/unknown')
        free = view.get('destination_free_bytes')
        remaining = max(0, total - processed)
        capacity_var.set(f'Free destination space: {fmt_bytes(free)}' if free is not None
                         else 'Free destination space: unknown')
        destination_var.set('Destination: ' + str(view.get('destination', 'unknown'))[-110:])
        if missing:
            warning_var.set('Some bytes could not be read. This image is INCOMPLETE; see the recovery map.')
            warning_label.configure(fg=C['fail'])
        elif free is not None and phase != 'RETRY' and free < remaining:
            warning_var.set('Destination may run out of space before the image finishes; free space is below the remaining logical data.')
            warning_label.configure(fg=C['warn'])
        else:
            warning_var.set('No unreadable regions reported so far. Unscanned areas are NOT confirmed healthy.')
            warning_label.configure(fg=C['muted'])
        compact = event.get('map')
        if isinstance(compact, str) and compact:
            nonlocal map_dirty
            for i in range(len(map_cells)):
                idx = min(len(compact) - 1, i * len(compact) // len(map_cells))
                map_cells[i] = compact[idx] if compact[idx] in color_for else '.'
            map_dirty = True

    def apply_progress(event: dict) -> None:
        if event.get('workflow') == 'rescue':
            apply_rescue(event)
            return
        nonlocal map_dirty
        phase = str(event.get("phase") or stats["phase"])
        stats["phase"] = phase
        phase_var.set(phase)
        stats["message"] = str(event.get("message") or stats["message"])
        msg_var.set(stats["message"])
        stats["offset"] = int(event.get("offset") or 0)
        stats["size"] = int(event.get("size") or stats["size"] or 0)
        if event.get("latency_ms") is not None:
            stats["latency_ms"] = event["latency_ms"]
        if event.get("median_ms") is not None:
            stats["median_ms"] = event["median_ms"]
        stats["rewritten"] = int(event.get("rewritten_bytes") or stats["rewritten"])
        stats["verified"] = int(event.get("verified_bytes") or stats["verified"])
        health = event.get("health") or stats["health"]
        stats["health"] = health
        if all(str(health.get(k, 'UNKNOWN')).upper() == 'UNKNOWN'
               for k in ('media', 'transport', 'mechanical')):
            health_var.set('Drive health not established · SMART or physical testing needed')
        else:
            health_var.set(
                f"Media {health.get('media', 'unknown')} · "
                f"Transport {health.get('transport', 'unknown')} · "
                f"Mechanical indicator {health.get('mechanical', 'unknown')} "
                '(latency estimate, not a physical sensor)'
            )
        # Percent from probe or refresh indices.
        pi, pt = int(event.get("probe_index") or 0), int(event.get("probe_total") or 0)
        ri, rt = int(event.get("refresh_index") or 0), int(event.get("refresh_total") or 0)
        if phase == "PROBE" and pt:
            pct = 100.0 * pi / pt
        elif rt:
            pct = 100.0 * ri / rt
        else:
            pct = stats["pct"]
        stats["pct"] = pct
        pbar["value"] = max(0, min(1000, int(pct * 10)))
        lat = stats["latency_ms"]
        med = stats["median_ms"]
        # Scan/repair telemetry uses actual attempted/readable bytes from the
        # engine. Do NOT use bytes-written counters for a read-only scan.
        if phase in {'SCANNING', 'INVESTIGATING'}:
            for label, text in zip(summary_labels, ('BYTES READ', 'READ ERRORS',
                                                    'RECENT SPEED', 'TIME REMAINING')):
                label.configure(text=text)
            attempted = int(event.get('attempted_bytes', 0))
            readable = int(event.get('readable_bytes', 0))
            stats['scan_attempted'] = max(stats.get('scan_attempted', 0), attempted)
            stats['scan_readable'] = max(stats.get('scan_readable', 0), readable)
            recovered_var.set(fmt_bytes(stats['scan_readable']))
            error_count = int(event.get('read_error_chunks') or 0)
            errors_var.set(f'{error_count} failed region(s)' if error_count else '0 observed')
            speed_bps = event.get('speed_bps')
            if speed_bps is not None and float(speed_bps) > 0:
                speed_var.set(f'{fmt_bytes(int(speed_bps))}/s')
            elif phase == 'INVESTIGATING':
                speed_var.set('Targeted retries')
            elif speed_bps is None:
                speed_var.set('Measuring…')
            eta_s = event.get('eta_seconds')
            if phase == 'INVESTIGATING':
                eta_var.set('Bounded retries')
            elif eta_s is not None:
                eta_var.set(format_duration(float(eta_s)) if float(eta_s) > 0 else 'Finishing…')
            capacity_var.set('Read-only investigation — no output image')
            destination_var.set('Destination: not used during scan')
            legend_var.set('Scan map · colors identify sampled areas; other areas remain untested')
            warning_var.set('Read errors trigger bounded investigation; unknown bytes are NEVER overwritten automatically.')
            warning_label.configure(fg=C['warn'] if error_count else C['muted'])
        elif phase == 'REFRESH':
            for label, text in zip(summary_labels, ('BYTES REWRITTEN / VERIFIED',
                                                    'UNREADABLE / UNKNOWN',
                                                    'RECENT SPEED', 'TIME REMAINING')):
                label.configure(text=text)
            recovered_var.set(f"{fmt_bytes(stats['rewritten'])} / {fmt_bytes(stats['verified'])}")
            remaining_errors = int(event.get('read_error_chunks') or 0)
            errors_var.set(f'{remaining_errors} original error region(s)' if remaining_errors
                           else 'None reported')
            speed_bps = event.get('speed_bps')
            if speed_bps and float(speed_bps) > 0:
                speed_var.set(f'{fmt_bytes(int(speed_bps))}/s')
            if event.get('eta_seconds') is not None:
                eta_var.set(format_duration(float(event['eta_seconds'])))
            elif not speed_bps:
                eta_var.set('Measuring…')
            destination_var.set('Destination: selected patient disk (in-place rewrite)')
            capacity_var.set('No image destination')
        elif event.get('speed_bps') is not None:
            speed_bps = event.get('speed_bps')
            if speed_bps and float(speed_bps) > 0:
                speed_var.set(f'{fmt_bytes(int(speed_bps))}/s')
            if event.get('eta_seconds') is not None:
                eta_var.set(format_duration(float(event['eta_seconds'])))
        if event.get('failed') and phase not in {'SCANNING', 'INVESTIGATING'}:
            errors_var.set('read errors observed')
        measure = (f"read {stats.get('scan_attempted', 0) / (1024 * 1024):.2f} MiB"
                   if phase in {'SCANNING', 'INVESTIGATING'} else
                   f"rewritten {stats['rewritten'] / (1024 * 1024):.2f} MiB")
        metric_var.set(
            f"{pct:5.1f}% done\n"
            f"lat {('—' if lat is None else f'{lat:.0f} ms'):>8}   med {('—' if med is None else f'{med:.0f} ms'):>8}\n"
            f"{measure}"
        )
        symbol = "o"
        if event.get("failed"):
            symbol = "X"
        elif phase == "ESCALATE":
            symbol = "!"
        elif lat is not None and med is not None and lat >= max(med * 2, 1):
            symbol = "S"
        if stats["size"]:
            mark_map(stats["offset"], stats["size"], symbol,
                     event.get('read_length', 0))
        compact = event.get("map")
        if isinstance(compact, str) and compact:
            for i, ch in enumerate(compact):
                idx = min(len(map_cells) - 1, int(i * len(map_cells) / max(1, len(compact))))
                map_cells[idx] = ch if ch in color_for else map_cells[idx]
            map_dirty = True

    def start(args: list[str], title: str, *, risky: bool = False, destructive: bool = False) -> None:
        """Stage a job for confirmation. Invoking workflow controls cannot run I/O."""
        nonlocal staged_job
        if PUBLIC_BETA_IMAGE_ONLY and args and args[0] in IN_PLACE_WRITE_COMMANDS:
            messagebox.showwarning('Public beta: image-first',
                'In-place rewriting of an image or physical disk is disabled. Use Check or Rescue to a NEW image.')
            return
        if busy:
            messagebox.showwarning('Busy', 'Stop the current job before selecting another.')
            return
        staged_job = (list(args), str(title), bool(risky), bool(destructive))
        status.set(f'READY: {title} — review the settings, then click Start job')
        phase_var.set('READY TO START')
        msg_var.set(f'{title} is selected but NOT running')
        cancel_button.configure(text='Start job', command=launch_pending, state='normal')

    def launch_pending() -> None:
        nonlocal staged_job
        if busy or staged_job is None:
            return
        args, title, risky, destructive = staged_job
        if '--ack-media-warning' in args:
            if not messagebox.askyesno('SMART media warning',
                    'The drive has a media warning. Rewrites can worsen damage. Continue?'):
                return
        if '--journal-backend' in args and 'memory' in args:
            if not messagebox.askyesno('No-backup RAM-only operation',
                    'Only the current region is held in process memory. A crash, USB reset or '
                    'power loss could permanently lose it. No saved recovery journal exists. Continue?'):
                return
        launch_job(args, title, risky=risky, destructive=destructive)
        if busy:
            staged_job = None

    def launch_job(args: list[str], title: str, *, risky: bool = False, destructive: bool = False) -> None:
        nonlocal process, busy, last_result, active_command
        if busy:
            messagebox.showwarning("Busy", "A job is already active.")
            return
        if risky and not messagebox.askyesno(
            "Read risk",
            "This reads a physical drive. Unstable hardware can worsen or disconnect. Continue?",
        ):
            return
        if destructive:
            if not messagebox.askyesno(
                "Destructive acknowledgement",
                "In-place refresh WRITES the patient disk. A crash or USB failure may permanently "
                "destroy recoverable data. A rolling journal is NOT a backup. Continue?",
            ):
                return
            selected_id = chosen_device()
            typed = simpledialog.askstring(
                "Confirm destructive target",
                f"Type the exact selected device ID to authorize writes:\n{selected_id}",
                parent=root,
            )
            if typed != selected_id:
                messagebox.showerror("Not authorized", "Device ID confirmation did not match; no write started.")
                return
        args = prepare_child_arguments(args)
        command = recovery_command(args)
        active_command = list(args)
        last_result = None
        write(f"\n=== {title} ===\n")
        status.set(f"Running: {title}")
        phase_var.set("STARTING")
        msg_var.set(title)
        stats["started"] = time.monotonic()
        stats['scan_attempted'] = 0
        stats['scan_readable'] = 0
        rescue_metrics.__init__()
        recovered_var.set('—')
        errors_var.set('—')
        speed_var.set('—')
        eta_var.set('—')
        in_place = bool(args and args[0] in {'care-external', 'care-image',
                         'refresh-external', 'refresh-system', 'refresh-image'})
        capacity_var.set('No image needed for in-place repair' if in_place
                         else 'Free space: checking…')
        warning_var.set('Recovery may stress failing hardware. This display is not a drive-health verdict.')
        warning_label.configure(fg=C['muted'])
        for label, text in zip(summary_labels, ('DATA SAVED TO IMAGE', 'UNREADABLE / UNKNOWN',
                                                'RECENT SPEED', 'TIME REMAINING')):
            label.configure(text=text)
        if in_place:
            summary_labels[0].configure(text='BYTES REWRITTEN / VERIFIED')
            destination_var.set('Destination: original selected drive')
            legend_var.set('Repair map · . unscanned  o read  S slow  X unreadable (skipped)')
        else:
            legend_var.set('Activity map · . unscanned  o read to image  ? in progress  X unreadable/unknown')
        reset_map()
        set_dashboard_visible(True)
        busy = True
        cancel_button.configure(text='Stop job', command=cancel, state='normal')

        def worker() -> None:
            nonlocal process
            try:
                child = subprocess.Popen(
                    command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    text=True, encoding='utf-8', errors='replace', bufsize=1,
                    env={**os.environ, 'PYTHONIOENCODING': 'utf-8'},
                )
                process = child

                output_lines: list[str] = []
                output_chars = [0]
                def pump(stream, kind: str) -> None:
                    assert stream is not None
                    for line in stream:
                        if kind == 'stdout' and output_chars[0] < 2_000_000:
                            output_lines.append(line)
                            output_chars[0] += len(line)
                        q.put((kind, line))

                stdout_thread = threading.Thread(target=pump, args=(child.stdout, "stdout"), daemon=True)
                stderr_thread = threading.Thread(target=pump, args=(child.stderr, "stderr"), daemon=True)
                stdout_thread.start()
                stderr_thread.start()
                code = child.wait()
                if child.stdin is not None:
                    child.stdin.close()
                stdout_thread.join(timeout=3)
                stderr_thread.join(timeout=3)
                # Release pipe descriptors once the stream readers have drained.
                # Otherwise repeated rescues leak handles on Windows and Linux.
                if child.stdout is not None:
                    child.stdout.close()
                if child.stderr is not None:
                    child.stderr.close()
                try:
                    final_result = json.loads(''.join(output_lines))
                    if isinstance(final_result, dict):
                        q.put(('job_result', final_result))
                except (ValueError, TypeError):
                    pass
                q.put(("done", (title, code)))
            except (OSError, ValueError) as exc:
                q.put(("stdout", f"Unable to start: {exc}\n"))
                q.put(("done", (title, -1)))

        threading.Thread(target=worker, daemon=True).start()

    def cancel() -> None:
        if process is None or process.poll() is not None:
            return
        command_name = command_for_running_job()
        potentially_writing = command_name in POTENTIALLY_WRITING_OPERATIONS
        cooperative = command_name in COOPERATIVE_STOP_OPERATIONS
        message = ('Request a safe stop? The current write transaction must finish; '
                   'DriveRepair will keep running until the engine acknowledges STOP.'
                   if potentially_writing else 'Stop the active read-only job?')
        if not messagebox.askyesno('Stop job', message):
            return
        if cooperative and process.stdin is not None:
            try:
                process.stdin.write('STOP\n')
                process.stdin.flush()
            except (BrokenPipeError, OSError, ValueError):
                status.set('Stop channel unavailable; waiting for engine exit')
            else:
                status.set('Stop requested — waiting for the active I/O boundary')
        elif potentially_writing:
            messagebox.showwarning('Cannot force-stop a write',
                'This operation has no verified cooperative stop. Keep DriveRepair open and '
                'allow it to reach a safe completion boundary. Do not disconnect the drive.')
        else:
            process.terminate()
            status.set('Read-only process termination requested; last I/O result unknown')

    def command_for_running_job() -> str:
        # This is the previously staged command, never the next workflow choice.
        return active_command[0] if active_command else ''

    # --- Diagnose / rescue tab ---
    ttk.Label(tab_drive, text="External whole disks only. Prefer image rescue before any in-place work.",
              style="Muted.TLabel", wraplength=900).pack(anchor="w")
    tree = ttk.Treeview(tab_drive, show="headings",
                        columns=("id", "model", "size", "bus", "serial", "location", "verify"), height=6)
    for key, width in [("id", 190), ("model", 180), ("size", 110), ("bus", 65), ("serial", 90),
                       ("location", 135), ("verify", 115)]:
        tree.heading(key, text=key.upper())
        tree.column(key, width=width, stretch=(key == "model"))
    tree.pack(fill="x", pady=8)
    def select_device(_event=None):
        item = tree.selection()
        selected.set(item[0] if item else 'No external drive selected')
        if item and item[0] in inventory:
            d = inventory[item[0]]
            profile = identify_profile(model=d.model, bus=d.bus, sector=d.sector_size)
            detected_medium.set(f'{profile.kind.upper()} · {profile.evidence}. {profile.maintenance_note}')
            health_var.set(f'{d.model} · {d.size_bytes/10**9:.2f} GB · {d.bus.upper()} · '
                           'Health not checked (SMART recommended)')
    tree.bind('<<TreeviewSelect>>', select_device)
    ttk.Label(tab_drive, textvariable=selected).pack(anchor="w")
    detected_medium = tk.StringVar(value='Select a drive to identify its media profile.')
    ttk.Label(tab_drive, textvariable=detected_medium, style='Muted.TLabel',
              wraplength=920).pack(anchor='w', pady=(2, 8))

    def refresh_devices() -> None:
        if busy:
            messagebox.showwarning("Busy", "Finish the current job first.")
            return

        def worker():
            try:
                from .devices import list_external_devices
                q.put(("devices", list_external_devices()))
            except (OSError, ValueError, RuntimeError) as exc:
                q.put(("stdout", f"Discovery failed: {exc}\n"))

        threading.Thread(target=worker, daemon=True).start()
        status.set("Discovering external disks…")

    def chosen_device() -> str:
        value = selected.get()
        if not value.startswith(("linux:", "windows:", "macos:")):
            raise ValueError("Select an external drive from the inventory.")
        return value

    # The main recovery page must offer the no-image / no-output choice.
    quick_repair_storage = tk.StringVar(value=(
        'Volatile RAM only (no recovery image/journal)' if prefs['repair_storage'] == 'memory'
        else 'Disk journal (crash recoverable)'))
    remember_weak_regions = tk.BooleanVar(value=True)
    guided_repair_policy = tk.StringVar(value=(
        'Balanced: bounded error recovery + weak regions' if prefs['repair_policy'] == 'balanced'
        else 'Preserve data: no read error retries'))

    def save_repair_preferences(*_unused: object) -> None:
        try:
            save_preferences({'schema': 1,
                'repair_storage': ('memory' if quick_repair_storage.get().startswith('Volatile RAM') else 'disk'),
                'repair_policy': ('balanced' if guided_repair_policy.get().startswith('Balanced') else 'preserve'),
                'dashboard': bool(dashboard_visible.get())})
        except OSError:
            # Optional preferences must not interfere with recovery controls.
            status.set('Could not save UI preferences; operation choices remain usable')

    quick_repair_storage.trace_add('write', save_repair_preferences)
    guided_repair_policy.trace_add('write', save_repair_preferences)
    ack_media_warn = tk.BooleanVar(value=False)

    def device_action(kind: str) -> None:
        try:
            dev = chosen_device()
            if kind == "health":
                start(["health", "--device", dev, "--json"], "SMART health")
            elif kind in {"sample", "full"}:
                if sys.platform not in {"win32"} and not sys.platform.startswith("linux"):
                    raise ValueError("Raw-drive refresh is not qualified for macOS. "
                                     "Read-only scans and image recovery remain available.")
                if dev not in inventory:
                    raise ValueError("Refresh disk inventory before selecting this patient")
                mode = "quick" if kind == "sample" else "full"
                if mode == "quick":
                    from .media_profiles import format_quick_preflight
                    size = getattr(inventory[dev], 'size_bytes', None)
                    if not messagebox.askokcancel(
                        'Quick Repair preflight',
                        format_quick_preflight(size) +
                        '\n\nQuick Repair then may rewrite slow-but-readable regions '
                        '(destructive). Continue?'):
                        return
                volatile = quick_repair_storage.get().startswith('Volatile RAM')
                journal = str(Path(journal_dir.get()).expanduser()) + (
                    f'-guided-{inventory[dev].fingerprint[:12]}-{time.time_ns()}')
                flags = [
                    "--ack-risk", "--ack-destructive", "--ack-no-backup",
                    "--ack-data-loss-risk", "--ack-usb-bridge-risk",
                    "--ack-unvalidated-hardware", "--confirm-identity",
                    inventory[dev].fingerprint[:12],
                ]
                if unknown_health_override.get():
                    flags.append('--ack-unknown-health')
                if ack_media_warn.get():
                    flags.append('--ack-media-warning')
                flags += ['--repair-policy', 'balanced' if guided_repair_policy.get().startswith('Balanced') else 'preserve']
                if volatile:
                    flags += ['--journal-backend', 'memory', '--ack-volatile-journal']
                else:
                    flags += ['--journal-backend', 'disk', '--journal', journal]
                if remember_weak_regions.get():
                    flags.append('--remember-anomalies')
                start(['care-external', '--device', dev, '--mode', mode,
                       *flags, '--json'],
                      f'{mode.title()} scan + targeted in-place repair', risky=True, destructive=True)
            elif kind == "diagnose":
                from .media_profiles import format_quick_preflight
                size = getattr(inventory.get(dev), 'size_bytes', None) if dev in inventory else None
                # Triage uses fewer samples than Quick Repair's ~10% plan; still show geometry estimate.
                if not messagebox.askokcancel(
                    'Read-only diagnosis preflight',
                    format_quick_preflight(size) +
                    '\n\nThis diagnosis path is read-only triage (not Quick Repair). Continue?'):
                    return
                start(["scan", "--device", dev, "--mode", "triage", "--json"],
                      "Read-only quick diagnosis", risky=True)
            elif kind == "benchmark":
                start(["benchmark-external", "--device", dev, "--ack-risk", "--json"],
                      "Benchmark", risky=True)
            elif kind in {"rescue", "resume"}:
                if not (sys.platform.startswith('linux') or sys.platform == 'win32'):
                    raise ValueError('Live external rescue is limited to Linux and Windows. '
                                     'On macOS, first create an image with a separately validated tool.')
                out = require(dest_file, "new image destination")
                opts = (["--resume"] if kind == "resume" else [])
                start(["rescue-external", "--device", dev, "--output", out,
                       "--ack-risk", "--multi-pass", *opts, "--json"],
                      "Resume external rescue" if kind == "resume" else "External rescue", risky=True)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))

    bf = ttk.Frame(tab_drive)
    bf.pack(anchor="w", pady=8)
    ttk.Button(bf, text="Refresh inventory", command=refresh_devices).pack(side="left", padx=(0, 6))
    for label, kind in [("SMART", "health"),
                        ("Quick repair", "sample"),
                        ("Full repair", "full"),
                        ("Rescue to image", "rescue"),
                        ("Resume rescue", "resume")]:
        ttk.Button(bf, text=label, command=lambda k=kind: device_action(k)).pack(side="left", padx=(0, 6))
    ttk.Label(tab_drive, text='Quick Repair samples 10% of the disk; Full Repair visits the full surface. '
              'Choose the operation, check the settings, then press Start job below.',
              style='Muted.TLabel', wraplength=980).pack(anchor='w', pady=(2, 8))
    policy_row = ttk.Frame(tab_drive)
    policy_row.pack(fill='x', pady=(4, 2))
    ttk.Label(policy_row, text='Repair policy:').pack(side='left')
    ttk.Combobox(policy_row, textvariable=guided_repair_policy, state='readonly',
                 values=['Balanced: bounded error recovery + weak regions',
                         'Preserve: refresh consistent slow regions only'],
                 width=52).pack(side='left', padx=(6, 12))
    ttk.Checkbutton(policy_row, text='Allow repair of verified candidates on SMART warning (high risk)',
                    variable=ack_media_warn).pack(side='left')
    history_checkbox = ttk.Checkbutton(tab_drive, text='Remember bad/slow disk locations (optional local metadata; no sector bytes)',
                    variable=remember_weak_regions)
    history_checkbox.pack(anchor='w', pady=(1, 4))
    storage = ttk.Frame(tab_drive)
    storage.pack(fill='x', pady=(2, 8))
    ttk.Label(storage, text='Temporary region storage:').pack(side='left')
    ttk.Combobox(storage, textvariable=quick_repair_storage, state='readonly', width=42,
                 values=['Volatile RAM only (no recovery image/journal)',
                         'Disk journal (crash recoverable)']).pack(side='left', padx=8)
    ttk.Label(storage, text='No image created; RAM-only loses crash recovery.',
              style='Muted.TLabel').pack(side='left')
    secondary = ttk.Frame(tab_drive)
    secondary.pack(fill="x", pady=(0, 6))
    ttk.Button(secondary, text="Read-only quick check",
               command=lambda: device_action("diagnose")).pack(side="left", padx=(0, 8))
    ttk.Button(secondary, text="Benchmark (read-only)",
               command=lambda: device_action("benchmark")).pack(side="left", padx=(0, 8))
    # Firmware checking is read-only; optimization uses OS-native volume tools.
    def firmware_action() -> None:
        try:
            start(['firmware-info', '--device', chosen_device(), '--json'],
                  'Firmware inventory (read-only)')
        except ValueError as exc:
            messagebox.showerror('Device selection', str(exc))

    def optimize_action() -> None:
        try:
            dev = chosen_device()
            if sys.platform != 'win32':
                raise ValueError('This optimizer uses Windows Optimize-Volume; other OS tools are not yet integrated.')
            letter = simpledialog.askstring('Optimize a healthy volume',
                'Which drive letter is mounted on the selected disk? (e.g. E)')
            if letter is None:
                return
            if not (len(letter) == 1 and letter.isalpha() and letter.isascii()):
                raise ValueError('Enter one drive letter (e.g. E), without a colon')
            start(['optimize-volume', '--device', dev, '--letter', letter.upper(), '--json'],
                  'Drive-aware optimization plan (read-only)')
        except ValueError as exc:
            messagebox.showerror('Optimize volume', str(exc))

    def investigate_error_region() -> None:
        try:
            dev = chosen_device()
            if dev not in inventory:
                raise ValueError('Refresh inventory before investigating a physical disk')
            at = simpledialog.askinteger('Investigate failed region',
                'Enter the BYTE OFFSET from the earlier Full Scan report.\n'
                'The probe reads at most 8 MiB and does not write to the drive.',
                minvalue=0)
            if at is None:
                return
            sector = inventory[dev].sector_size
            if at % sector:
                raise ValueError(f'Offset must be aligned to {sector}-byte logical sectors')
            if not messagebox.askyesno('Read stress on a possibly failing drive',
                'This performs up to 32 read-only requests around the failing offset. '
                'A severely failing drive may deteriorate further. Continue?'):
                return
            start(['probe-region', '--device', dev, '--offset', str(at),
                   '--length', '4194304', '--max-reads', '32',
                   '--confirm-identity', inventory[dev].fingerprint[:12],
                   '--ack-read-stress', '--json'],
                  'Read-only failed-region investigation', risky=True)
        except ValueError as exc:
            messagebox.showerror('Investigate read failure', str(exc))

    tools_row = ttk.Frame(tab_drive)
    tools_row.pack(fill='x', pady=(0, 5))
    ttk.Button(tools_row, text='Firmware info', command=firmware_action).pack(side='left', padx=(0, 6))
    ttk.Button(tools_row, text='Optimize advice', command=optimize_action).pack(side='left', padx=(0, 6))
    ttk.Button(tools_row, text='Investigate a failed offset (read-only)',
               command=investigate_error_region).pack(side='left')
    ttk.Label(tools_row, text='Use a byte offset reported by a stopped Full Scan.',
              style='Muted.TLabel').pack(side='left', padx=8)
    expert_frames = (policy_row, history_checkbox, secondary, tools_row)
    def show_expert_settings() -> None:
        if expert_settings.get():
            for panel in expert_frames:
                if not panel.winfo_manager():
                    panel.pack(fill='x', pady=(3, 4))
        else:
            for panel in expert_frames:
                panel.pack_forget()
    ttk.Checkbutton(tab_drive, text='Advanced settings · firmware, benchmarks, risk policies',
                    variable=expert_settings, command=show_expert_settings).pack(anchor='w', pady=(2, 8))
    # Show device selection, goal, journal choice and Start by default.
    show_expert_settings()
    unknown_health_override = tk.BooleanVar(value=False)
    ttk.Checkbutton(secondary, text="Permit manual risk override if SMART is unavailable",
                    variable=unknown_health_override).pack(side="left", padx=(4, 0))
    ttk.Label(tab_drive,
              text="Guided repair auto-tunes scanning, then journals/rewrites/verifies only safely readable slow regions. "
                   "It will stop and recommend rescue if read errors or health warnings are found. "
                   "A clean scan does not prove file integrity; no identified problem means no write.",
              style="Muted.TLabel", wraplength=890).pack(anchor="w", pady=(2, 12))
    ttk.Label(
        tab_drive,
        text='Read-only check diagnoses. Quick repair and Full repair scan and then rewrite/verify '
             'ONLY slow, consistently readable regions after approval. Full surface rewrite is '
             'available on the In-place refresh tab. None of these repairs missing file bytes.',
        style='Muted.TLabel', wraplength=980,
    ).pack(anchor='w', pady=(4, 0))
    row(tab_drive, "Rescue image output", dest_file, pick_output)

    # --- Image recovery ---
    ttk.Label(tab_image, text="Read regular files only. Outputs are always new paths.",
              style="Muted.TLabel").pack(anchor="w")
    row(tab_image, "Source image / ZIP", image, pick_file)
    row(tab_image, "New image output", dest_file, pick_output)
    row(tab_image, "New recovery directory", dest_dir, pick_dir)

    def image_action(kind: str) -> None:
        try:
            src = require(image, "source image")
            if kind == "scan":
                start(["scan-image", "--image", src, "--mode", "sample", "--json"], "Scan image")
            elif kind in {"rescue", "resume", "retry"}:
                flags = (["--resume", "--retry-missing"] if kind == "retry" else
                         ["--resume", "--multi-pass"] if kind == "resume" else ["--multi-pass"])
                start(["rescue-image", "--image", src, "--output", require(dest_file, "output"),
                       *flags, "--json"],
                      "Retry unreadable regions" if kind == "retry" else
                      "Resume image rescue" if kind == "resume" else "Rescue image")
            elif kind == "verify":
                start(["verify-images", "--image", src,
                       "--output", require(dest_file, "rescued image"), "--json"], "Verify images")
            elif kind == "carve":
                start(["carve-image", "--image", src,
                       "--output-dir", require(dest_dir, "directory"), "--json"], "Carve photos")
            elif kind == "undelete":
                start(["undelete-fat32", "--image", src,
                       "--output-dir", require(dest_dir, "directory"), "--json"], "FAT32 undelete")
            elif kind == "zip":
                start(["salvage-zip", "--archive", src,
                       "--output-dir", require(dest_dir, "directory"), "--json"], "Salvage ZIP")
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))

    ib = ttk.Frame(tab_image)
    ib.pack(anchor="w", pady=8)
    for label, kind in [("Scan", "scan"), ("Rescue", "rescue"),
                        ("Resume", "resume"), ("Retry gaps", "retry"), ("Verify", "verify"),
                        ("Carve", "carve"), ("FAT32 undelete", "undelete"), ("ZIP salvage", "zip")]:
        ttk.Button(ib, text=label, command=lambda k=kind: image_action(k)).pack(side="left", padx=(0, 6))

    # --- Image integrity: reference hashes and verified replacement data ---
    ttk.Label(tab_integrity, text='Integrity checks require a PREVIOUSLY trusted baseline or independent good copy. '
              'A new checksum of already-corrupt data cannot reveal the original value. '
              'No physical disk writes are performed here.',
              style='Muted.TLabel', wraplength=910).pack(anchor='w', pady=(0, 8))
    row(tab_integrity, 'Image to examine', image, pick_file)
    def select_integrity_file(var, title, save=False):
        chosen = (filedialog.asksaveasfilename(title=title, defaultextension='.json' if 'manifest' in title.lower() else '.img')
                  if save else filedialog.askopenfilename(title=title))
        if chosen:
            var.set(chosen)
    row(tab_integrity, 'Reference hash manifest', integrity_manifest,
        lambda: select_integrity_file(integrity_manifest, 'Choose known-good manifest'))
    row(tab_integrity, 'Known-good image', integrity_reference,
        lambda: select_integrity_file(integrity_reference, 'Choose independent good reference image'))
    row(tab_integrity, 'New corrected image', integrity_output,
        lambda: select_integrity_file(integrity_output, 'Save NEW corrected image', save=True))
    ttk.Label(tab_integrity, textvariable=integrity_summary, style='Muted.TLabel',
              wraplength=900).pack(anchor='w', pady=(5, 10))
    def integrity_action(kind):
        try:
            src = require(image, 'image')
            manifest = require(integrity_manifest, 'manifest location')
            if kind == 'baseline':
                # Creating a baseline does NOT certify the image. A separate, trusted
                # baseline must have been captured before corruption occurred.
                if not messagebox.askyesno('Baseline trust',
                    'This saves hashes of the current image, even if it is already corrupted. '
                    'It does NOT restore earlier correct bits. Continue?'):
                    return
                start(['integrity-baseline', '--image', src, '--output', manifest, '--json'],
                      'Create UNATTESTED integrity baseline')
            elif kind == 'audit':
                start(['integrity-audit', '--image', src, '--manifest', manifest, '--json'],
                      'Audit known-hash integrity')
            elif kind == 'restore':
                if not messagebox.askyesno('Trusted restoration',
                    'The independent reference must represent the SAME data snapshot. '
                    'Legitimate file changes since the baseline will otherwise look corrupt. '
                    'This creates a NEW image; it never modifies the original. Continue?'):
                    return
                start(['integrity-restore-copy', '--image', src,
                       '--reference', require(integrity_reference, 'known-good reference image'),
                       '--manifest', manifest, '--ack-same-snapshot',
                       '--output', require(integrity_output, 'new corrected image'), '--json'],
                      'Restore hash-verified chunks to new image')
        except ValueError as exc:
            messagebox.showerror('Integrity input', str(exc))
    actions_integrity = ttk.Frame(tab_integrity)
    actions_integrity.pack(anchor='w', pady=5)
    for label, kind in [('Create baseline (not a proof)', 'baseline'),
                        ('Check for changed chunks', 'audit'),
                        ('Restore proven chunks to NEW image', 'restore')]:
        ttk.Button(actions_integrity, text=label,
                   command=lambda k=kind: integrity_action(k)).pack(side='left', padx=(0, 6))

    # --- Targeted deleted-file recovery (read-only catalog, explicit selection) ---
    ttk.Label(tab_undelete,
              text="1. Choose a disk image.  2. Preview deleted files without writing.  "
                   "3. Select only the files you need.  4. Recover to a NEW folder.  "
                   "FAT32 contiguous files only; overwrites and fragmentation cannot be undone.",
              style="Muted.TLabel", wraplength=910).pack(anchor="w", pady=(0, 8))
    row(tab_undelete, "Recovered disk image", image, pick_file)
    row(tab_undelete, "New recovered-files folder", dest_dir, pick_dir)
    deleted_options = ttk.Frame(tab_undelete)
    deleted_options.pack(anchor='w', fill='x', pady=4)
    backend_choice = tk.StringVar(value='FAT32 built-in')
    offset_choice = tk.StringVar(value='0')
    ttk.Label(deleted_options, text='Filesystem backend').pack(side='left')
    ttk.Combobox(deleted_options, textvariable=backend_choice,
                 values=['FAT32 built-in', 'Sleuth Kit (optional NTFS/exFAT/ext)'],
                 width=36, state='readonly').pack(side='left', padx=(4, 12))
    ttk.Label(deleted_options, text='Partition start (sectors)').pack(side='left')
    ttk.Entry(deleted_options, textvariable=offset_choice, width=12).pack(side='left', padx=4)
    deleted_tree = ttk.Treeview(tab_undelete, columns=("name", "size", "condition", "id"),
                                show="headings", selectmode="extended", height=10)
    for key, title, width in (("name", "Remaining filename", 260),
                               ("size", "Size", 110),
                               ("condition", "Current allocation", 250),
                               ("id", "Recovery ID", 190)):
        deleted_tree.heading(key, text=title)
        deleted_tree.column(key, width=width, stretch=(key == "name"))
    deleted_tree.pack(fill="both", expand=True, pady=8)
    catalog_source = {"path": "", "backend": "", "offset": 0}
    candidate_status = tk.StringVar(value="No deleted-file catalog loaded")
    ttk.Label(tab_undelete, textvariable=candidate_status, style="Muted.TLabel").pack(anchor="w")

    def preview_deleted() -> None:
        try:
            source = require(image, 'FAT32 image')
            if busy:
                raise ValueError('Wait for the active job to finish')
            catalog_source['path'] = ''
            backend = 'tsk' if backend_choice.get().startswith('Sleuth') else 'fat32'
            offset = int(offset_choice.get())
            if not 0 <= offset <= (1 << 48):
                raise ValueError('Invalid partition start offset')
            candidate_status.set('Scanning FAT32 directory entries (read-only)...')
            def worker():
                try:
                    from .fat32_undelete import list_deleted_fat32
                    from .tsk_recovery import list_deleted_tsk
                    from .encryption import require_plaintext_filesystem
                    require_plaintext_filesystem(source, operation='deleted-file preview', ack_encrypted_volume=False)
                    if backend == 'tsk':
                        result = list_deleted_tsk(source, offset_sectors=offset, max_candidates=2000)
                    else:
                        result = list_deleted_fat32(source, max_candidates=2000)
                    q.put(('deleted_candidates', (source, backend, offset, result)))
                except (OSError, ValueError, RuntimeError) as exc:
                    q.put(('deleted_error', str(exc)))
            threading.Thread(target=worker, daemon=True).start()
        except ValueError as exc:
            messagebox.showerror('Preview', str(exc))

    def recover_selected_deleted() -> None:
        try:
            src = require(image, 'FAT32 image')
            current_backend = 'tsk' if backend_choice.get().startswith('Sleuth') else 'fat32'
            current_offset = int(offset_choice.get())
            if (os.path.realpath(src) != catalog_source['path'] or
                    current_backend != catalog_source['backend'] or
                    current_offset != catalog_source['offset']):
                raise ValueError('Source or backend changed since preview. Preview again before recovering.')
            chosen = list(deleted_tree.selection())
            if not chosen:
                raise ValueError('Select one or more recoverable files from the list.')
            blocked = [iid for iid in chosen if deleted_tree.set(iid, 'condition') != 'Unallocated (tentative)']
            if blocked:
                raise ValueError('Selected entries include reallocated clusters; those cannot safely be restored.')
            output = require(dest_dir, 'NEW destination folder')
            if os.path.lexists(output):
                raise ValueError('Destination already exists; choose a new folder.')
            if not messagebox.askyesno('Extract selected files',
                    f'Extract {len(chosen)} selected speculative file(s) to a new folder? '
                    'Files may be overwritten or fragmented; the source image stays unchanged.'):
                return
            if current_backend == 'tsk':
                args = ['recover-selected-tsk', '--image', src, '--output-dir', output,
                        '--offset-sectors', str(current_offset), '--json']
            else:
                args = ['undelete-fat32', '--image', src, '--output-dir', output,
                        '--max-files', str(len(chosen)), '--json']
            for iid in chosen:
                args.extend(['--file-id', iid])
            start(args, f'Restore {len(chosen)} selected deleted files')
        except ValueError as exc:
            messagebox.showerror('Recover selected', str(exc))

    deleted_controls = ttk.Frame(tab_undelete)
    deleted_controls.pack(anchor='w', pady=4)
    ttk.Button(deleted_controls, text='1. Find deleted files', command=preview_deleted).pack(side='left', padx=4)
    ttk.Button(deleted_controls, text='2. Restore selected files', style='Accent.TButton',
               command=recover_selected_deleted).pack(side='left', padx=4)
    ttk.Label(tab_undelete, text='Optional Sleuth Kit backend uses installed fls/icat binaries. '
              'Filesystem support varies. Never restore to the patient disk or assume intact results.',
              style='Muted.TLabel', wraplength=900).pack(anchor='w', pady=6)

    # --- Failed system drive / trusted Linux live media ---
    ttk.Label(tab_system, text='Recover a computer whose internal OS drive is failing',
              font=('Segoe UI', 15, 'bold')).pack(anchor='w', pady=6)
    ttk.Label(tab_system,
              text='Boot a trusted Linux live USB FIRST. The failing system drive must be unmounted '
                   'and must have no active RAID, LVM or encryption holders. Choose a separate USB '
                   'disk or mounted NFS/CIFS/SSHFS share with enough space for an image. '
                   'The patient is NEVER opened for writing in this workflow.',
              style='Muted.TLabel', wraplength=910).pack(anchor='w', pady=(0, 12))
    offline_selected = tk.StringVar(value='No offline whole disk selected')
    offline_inventory = {}
    offline_tree = ttk.Treeview(tab_system, show='headings',
                  columns=('model','size','bus','serial','hint','id'), height=6)
    for key, width in [('model', 190), ('size', 120), ('bus', 110),
                       ('serial', 110), ('hint', 130), ('id', 190)]:
        offline_tree.heading(key, text=key.upper())
        offline_tree.column(key, width=width)
    offline_tree.pack(fill='x', pady=6)
    def choose_offline(event=None):
        chosen = offline_tree.selection()
        offline_selected.set(chosen[0] if chosen else 'No offline whole disk selected')
    offline_tree.bind('<<TreeviewSelect>>', choose_offline)
    ttk.Label(tab_system, textvariable=offline_selected).pack(anchor='w')
    row(tab_system, 'Image destination', dest_file, pick_output)
    ttk.Label(tab_system, text='NAS destinations must already be mounted by the live OS. '
              'If no separate destination has enough capacity, a full image is not possible; '
              'the experimental RAM-journal refresh option below can rewrite CONSISTENTLY READABLE sectors, '
              'but cannot salvage unreadable files or preserve a full backup.',
              style='Muted.TLabel', wraplength=900).pack(anchor='w', pady=(5, 10))

    def list_offline():
        if not sys.platform.startswith('linux'):
            messagebox.showwarning('Linux live environment required',
                                   'Offline internal-disk rescue is Linux-only in this release.')
            return
        if busy:
            return
        def worker():
            try:
                from .devices import linux_all_devices
                q.put(('offline_devices', linux_all_devices()))
            except (RuntimeError, OSError, ValueError) as exc:
                q.put(('stdout', f'Offline disk discovery failed: {exc}\n'))
        threading.Thread(target=worker, daemon=True).start()

    def offline_args():
        chosen = offline_tree.selection()
        if len(chosen) != 1 or chosen[0] not in offline_inventory:
            raise ValueError('Select exactly one offline system disk')
        device = offline_inventory[chosen[0]]
        return ['--device', device.id,
                '--output', require(dest_file, 'new image destination'),
                '--expect-fingerprint', device.fingerprint[:12]]

    def plan_offline():
        try:
            start(['plan-system-recovery', *offline_args(), '--json'],
                  'Check offline disk and destination (no imaging)')
        except ValueError as exc:
            messagebox.showerror('Preflight', str(exc))

    def rescue_offline(resume=False):
        try:
            opts = offline_args()
            if not messagebox.askyesno('Offline system drive only',
                    'Have you BOOTED A LIVE USB and made certain this is not a running/mounted '
                    'system drive? This operation reads the patient and writes an image to '
                    'separate storage. Continue?'):
                return
            start(['rescue-system', *opts, '--ack-risk', '--ack-offline-system',
                   '--multi-pass', *(['--resume'] if resume else []), '--json'],
                  'Resume read-only OS rescue' if resume else 'Read-only rescue of offline OS disk',
                  risky=True)
        except ValueError as exc:
            messagebox.showerror('Offline recovery', str(exc))
    row_sys = ttk.Frame(tab_system)
    row_sys.pack(anchor='w', pady=6)
    ttk.Button(row_sys, text='1. List offline disks', command=list_offline).pack(side='left', padx=4)
    ttk.Button(row_sys, text='2. Check destination', command=plan_offline).pack(side='left', padx=4)
    ttk.Button(row_sys, text='3. Rescue to image', style='Accent.TButton',
               command=rescue_offline).pack(side='left', padx=4)
    ttk.Button(row_sys, text='Resume image rescue',
               command=lambda: rescue_offline(resume=True)).pack(side='left', padx=4)

    ttk.Separator(tab_system).pack(fill='x', pady=12)
    ttk.Label(tab_system, text='Last resort: refresh readable sectors without a second drive',
              font=('Segoe UI', 12, 'bold')).pack(anchor='w')
    ttk.Label(tab_system,
              text='EXPERIMENTAL AND DESTRUCTIVE: This rewrites the installed drive, NOT a recovery '
                   'of unreadable/overwritten files. Requires Linux booted from trusted live USB; '
                   'the internal drive must be offline. RAM journals can disappear on host shutdown '
                   'even if a UPS is connected. Preserve critical files elsewhere whenever possible.',
              style='Muted.TLabel', wraplength=910).pack(anchor='w', pady=(4, 8))
    offline_ram_journal = tk.StringVar(value='/run/driverepair-journal/system-refresh')
    offline_ram_power = tk.StringVar(value='battery')
    row(tab_system, 'RAM journal (pre-mounted tmpfs)', offline_ram_journal)
    row(tab_system, 'Power telemetry (battery or nut:UPSNAME)', offline_ram_power)

    def refresh_offline_ram():
        try:
            chosen = offline_tree.selection()
            if len(chosen) != 1 or chosen[0] not in offline_inventory:
                raise ValueError('Select exactly one offline whole disk first')
            device = offline_inventory[chosen[0]]
            if not messagebox.askyesno('No-backup in-place rewrite — LAST RESORT',
                    'This will WRITE to the selected installed hard drive. It does not restore '
                    'unreadable data and may permanently destroy the remaining recoverable data '
                    'if the disk, computer, or RAM journal fails. A UPS is NOT a backup. '
                    'Have you booted a trusted Linux live USB and accepted the risk?'):
                return
            if not messagebox.askyesno('Confirm disk identity',
                    f'About to modify:\n{device.model}\n{device.public()["size_bytes"]} bytes\n'
                    f'{device.id}\nIdentity: {device.fingerprint[:12]}\n\n'
                    'This is NOT a data rescue. Confirm the exact drive?'):
                return
            args = [
                'refresh-system', '--device', device.id,
                '--confirm-identity', device.fingerprint[:12],
                '--journal', require(offline_ram_journal, 'RAM-backed journal path'),
                '--journal-backend', 'ramdisk', '--mode', 'adaptive',
                '--power-source', require(offline_ram_power, 'UPS/battery telemetry'),
                '--ack-offline-system', '--ack-risk', '--ack-destructive',
                '--ack-no-backup', '--ack-data-loss-risk', '--ack-unvalidated-hardware',
                '--ack-volatile-journal', '--after-run', 'keep',
                '--no-live-dashboard', '--progress-jsonl', '--json',
            ]
            if device.bus.lower() in {'usb', 'firewire', 'thunderbolt'}:
                if not messagebox.askyesno('External dock power',
                        'Is the USB dock independently UPS/battery powered, too?'):
                    return
                args.extend(['--ack-dock-power-backed', '--ack-usb-bridge-risk'])
            start(args, 'LAST RESORT: offline system refresh', risky=True, destructive=True)
        except ValueError as exc:
            messagebox.showerror('Last-resort refresh', str(exc))

    def check_offline_ram():
        try:
            start(['ram-journal-check',
                   '--journal', require(offline_ram_journal, 'RAM-backed journal path'),
                   '--power-source', require(offline_ram_power, 'UPS/battery telemetry'),
                   '--chunk-mib', '1', '--json'],
                  'Read-only RAM/power preflight')
        except ValueError as exc:
            if not offline_ram_power.get().strip():
                messagebox.showinfo('RAM-only alternative',
                    'This check applies to Linux tmpfs journaling, which requires live UPS/battery telemetry. '
                    'Volatile process-RAM mode (available under In-place refresh) does not require telemetry, '
                    'but cannot survive a crash or dock reset.')
            else:
                messagebox.showerror('RAM preflight', str(exc))

    ram_actions = ttk.Frame(tab_system)
    ram_actions.pack(anchor='w', pady=8)
    ttk.Button(ram_actions, text='1. Check RAM and power (read-only)',
               command=check_offline_ram).pack(side='left', padx=4)
    ttk.Button(ram_actions, text='2. EXPERIMENTAL: in-place refresh (no image)',
               command=refresh_offline_ram).pack(side='left', padx=4)

    # --- In-place refresh ---
    ttk.Label(
        tab_refresh,
        text="Dedicated In-Place Media Refresh. Rolling journal on healthy storage. "
             "Adaptive rewrite of consistently readable regions only; never a substitute for backup.",
        style="Muted.TLabel", wraplength=920,
    ).pack(anchor="w")
    row(tab_refresh, "Journal directory", journal_dir, pick_journal)
    mode_var = tk.StringVar(value="adaptive")
    backend_var = tk.StringVar(value="disk")
    power_var = tk.StringVar(value="")
    no_power_telemetry_ack = tk.BooleanVar(value=False)
    after_var = tk.StringVar(value="ask")
    samples_var = tk.StringVar(value="128")
    chunk_var = tk.StringVar(value="8")
    opts = ttk.Frame(tab_refresh)
    opts.pack(fill="x", pady=6)
    ttk.Label(opts, text="Mode").pack(side="left")
    ttk.Combobox(opts, textvariable=mode_var, values=["adaptive", "full"], width=10,
                 state="readonly").pack(side="left", padx=6)
    ttk.Label(opts, text="Journal").pack(side="left", padx=(12, 0))
    ttk.Combobox(opts, textvariable=backend_var, values=["disk", "ramdisk", "memory"], width=10,
                 state="readonly").pack(side="left", padx=6)
    ttk.Label(opts, text="After").pack(side="left", padx=(12, 0))
    ttk.Combobox(opts, textvariable=after_var, values=["ask", "keep", "delete"], width=8,
                 state="readonly").pack(side="left", padx=6)
    ttk.Label(opts, text="Chunk (MiB)").pack(side="left", padx=(12, 0))
    ttk.Combobox(opts, textvariable=chunk_var, values=["1", "4", "8", "16", "32", "64"],
                 width=4, state="readonly").pack(side="left", padx=6)
    ttk.Label(opts, text="Samples").pack(side="left", padx=(12, 0))
    ttk.Entry(opts, textvariable=samples_var, width=6).pack(side="left", padx=6)

    row(tab_refresh, "UPS/battery telemetry (ramdisk backend only)", power_var)
    ttk.Checkbutton(tab_refresh,
        text='Volatile process RAM: I understand there is no verified UPS telemetry or crash recovery',
        variable=no_power_telemetry_ack).pack(anchor='w', pady=(4, 3))
    ttk.Label(tab_refresh, text="ramdisk: Linux tmpfs (can survive app crash). "
              "memory: process RAM only, no files and no resume (Windows/Linux). "
              "Both are volatile; a UPS does not eliminate risk.",
              style="Muted.TLabel", wraplength=920).pack(anchor="w")

    def run_refresh() -> None:
        try:
            dev = chosen_device()
            journal = (require(journal_dir, 'journal directory')
                       if backend_var.get() != 'memory' else 'RAM_ONLY_NO_FILES')
            samples = max(8, min(4096, int(samples_var.get())))
            args = [
                "refresh-external", "--device", dev, "--journal", journal,
                "--mode", mode_var.get(), "--journal-backend", backend_var.get(),
                "--adaptive-samples", str(samples), "--after-run", after_var.get(),
                "--chunk-mib", chunk_var.get(),
                # GUI owns the map/health UI — disable TTY panel, keep JSONL only.
                "--no-live-dashboard", "--progress-jsonl",
                "--ack-risk", "--ack-destructive", "--ack-no-backup", "--ack-data-loss-risk",
                "--ack-usb-bridge-risk", "--ack-unvalidated-hardware", "--json",
            ]
            if dev not in inventory:
                raise ValueError('Rescan device inventory before attempting patient writes')
            args.extend(["--confirm-identity", inventory[dev].fingerprint[:12]])
            if backend_var.get() == 'memory':
                if not no_power_telemetry_ack.get():
                    raise ValueError('Check the volatile process-RAM risk acknowledgment; UPS telemetry is optional in this mode')
                if not messagebox.askyesno('NO BACKUP: PROCESS-RAM ONLY',
                        'No image, journal files, or recovery checkpoints will be saved. '
                        'A crash, USB reset, or power loss can permanently destroy '
                        'the active region. A UPS cannot eliminate this risk. Continue?'):
                    return
                if not messagebox.askyesno('USB dock risk',
                        'Do you understand the USB dock may lose power independently '
                        'and leave data irrecoverably damaged?'):
                    return
                args += ['--ack-volatile-journal', '--ack-dock-power-backed']
                index = args.index('--journal')
                del args[index:index + 2]  # no path, no journal files
            if backend_var.get() == 'ramdisk':
                if not messagebox.askyesno('VOLATILE RAM JOURNAL',
                        'Host restart, RAM loss or dock failure can permanently damage the disk. '
                        'Do you accept this risk and confirm BOTH laptop/UPS and dock are powered?'):
                    return
                args.extend(['--power-source', require(power_var, 'UPS/battery telemetry'),
                             '--ack-volatile-journal', '--ack-dock-power-backed'])
            stats["size"] = 0
            # Best-effort size from tree selection text is unknown; engine events fill it.
            start(args, f"In-place refresh ({mode_var.get()})", risky=True, destructive=True)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
        except Exception as exc:  # noqa: BLE001 — show sample parse errors
            messagebox.showerror("Input", str(exc))

    ttk.Button(tab_refresh, text="Repair this disk in place (no image)", style="Accent.TButton",
               command=run_refresh).pack(anchor="w", pady=10)
    ttk.Label(
        tab_refresh,
        text="Windows requires an Administrator session for physical writes. "
             "mechanical* is inferred from latency/errors — USB docks do not expose acoustic sensors.",
        style="Muted.TLabel", wraplength=920,
    ).pack(anchor="w")

    # --- Clone FS repair ---
    ttk.Label(tab_fs, text="Filesystem repair only on a NEW clone. Original stays read-only.",
              style="Muted.TLabel").pack(anchor="w")
    row(tab_fs, "Original ext image", image, pick_file)
    row(tab_fs, "New repaired copy", dest_file, pick_output)

    def inspect_ext() -> None:
        try:
            start(["check-ext-image", "--image", require(image, "ext image"), "--json"], "ext check")
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))

    def repair_ext() -> None:
        try:
            src, out = require(image, "ext image"), require(dest_file, "destination")
            if not messagebox.askyesno("Confirm", "Repair may discard corrupt references on the COPY only."):
                return
            if simpledialog.askstring("Approval", "Type REPAIR COPY:") != "REPAIR COPY":
                return
            start(["repair-ext-image", "--image", src, "--output", out, "--ack-repair", "--json"],
                  "Repair ext clone")
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))

    fb = ttk.Frame(tab_fs)
    fb.pack(anchor="w", pady=8)
    ttk.Button(fb, text="Read-only check", command=inspect_ext).pack(side="left", padx=(0, 6))
    ttk.Button(fb, text="Repair NEW copy", command=repair_ext).pack(side="left")

    def save_report() -> None:
        if last_result is None:
            messagebox.showinfo('No completed result', 'Finish a job before saving its final JSON report.')
            return
        chosen = filedialog.asksaveasfilename(title='Save DriveRepair job report',
                                              defaultextension='.json',
                                              filetypes=[('JSON report', '*.json')])
        if not chosen:
            return
        try:
            # Explicit export only; may contain selected device paths or identifiers.
            with open(chosen, 'x', encoding='utf-8') as f:
                json.dump(last_result, f, indent=2)
                f.write('\n')
            status.set('Saved report to ' + chosen)
        except FileExistsError:
            messagebox.showerror('Report exists', 'Choose a new report filename; existing reports are never overwritten.')
        except OSError as exc:
            messagebox.showerror('Save failed', str(exc))

    def open_destination() -> None:
        path = dest_file.get().strip() or dest_dir.get().strip()
        if not path:
            messagebox.showinfo('No destination', 'Choose a destination in the workflow first.')
            return
        directory = os.path.dirname(os.path.abspath(path))
        if not os.path.isdir(directory):
            messagebox.showerror('Destination unavailable', 'Destination parent folder does not exist.')
            return
        try:
            if sys.platform == 'win32':
                os.startfile(directory)  # type: ignore[attr-defined]
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', directory])
            else:
                subprocess.Popen(['xdg-open', directory])
        except OSError as exc:
            messagebox.showerror('Open failed', str(exc))

    statusbar = ttk.Frame(shell)
    statusbar.pack(fill="x", pady=(8, 0))
    ttk.Label(statusbar, textvariable=status).pack(side="left", fill="x", expand=True)
    cancel_button = ttk.Button(statusbar, text="Start job", command=launch_pending, state="disabled",
                               style="Accent.TButton")
    cancel_button.pack(side="right")
    ttk.Button(statusbar, text='Save report…', command=save_report).pack(side='right', padx=6)
    ttk.Button(statusbar, text='Open destination', command=open_destination).pack(side='right', padx=6)
    # Reserve the always-accessible Stop button and Advanced toggle at the
    # bottom BEFORE allowing the scrollable notebook to expand.
    notebook.pack_forget()
    log_controls.pack_forget()
    statusbar.pack_forget()
    statusbar.pack(side='bottom', fill='x', pady=(8, 0))
    log_controls.pack(side='bottom', fill='x', pady=(8, 0))
    notebook.pack(fill='both', expand=True)

    def check_prerequisites() -> None:
        from .dependencies import detect
        def worker():
            try:
                q.put(('prerequisites', detect()))
            except Exception as exc:
                q.put(('prerequisite_error', str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def install_smart_tools() -> None:
        if not messagebox.askyesno('Install optional SMART tools',
            'Allow Windows Package Manager to install smartmontools from the official package ID? '
            'This changes installed software and may require administrator approval. '
            'No drive firmware is modified. Continue?'):
            return
        prereq_install.configure(state='disabled')
        prerequisite_text.set('Installing smartmontools through Windows Package Manager…')
        def worker():
            try:
                from .dependencies import install_smartctl_windows
                q.put(('smartctl_install', install_smartctl_windows(approved=True)))
            except Exception as exc:
                q.put(('prerequisite_error', str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    prereq_install.configure(command=install_smart_tools)

    poll_after_id = None
    def poll() -> None:
        nonlocal process, busy, last_result, map_dirty, poll_after_id
        try:
            while True:
                kind, value = q.get_nowait()
                if kind == "stdout":
                    write(str(value))
                elif kind == "stderr":
                    line = str(value).rstrip("\n")
                    # Progress JSONL drives the dashboard; keep it out of Advanced log.
                    payload = line.strip()
                    json_start = payload.find('{"type":"progress"')
                    if json_start >= 0:
                        payload = payload[json_start:]
                    if payload.startswith("{"):
                        try:
                            event = json.loads(payload)
                            if event.get("type") == "progress":
                                apply_progress(event)
                                continue
                        except json.JSONDecodeError:
                            pass
                    # Ignore bare carriage-return SCAN paints; dashboard already shows %.
                    stripped = line.strip().lstrip('\r')
                    if stripped.startswith('SCAN  ') or not stripped:
                        continue
                    write(line + "\n")
                elif kind == 'deleted_error':
                    catalog_source['path'] = ''
                    candidate_status.set('Preview failed: ' + str(value))
                    write('FAT32 catalog error: ' + str(value) + '\n')
                elif kind == 'deleted_candidates':
                    source, backend, offset, result = value
                    catalog_source['path'] = os.path.realpath(source)
                    catalog_source['backend'] = backend
                    catalog_source['offset'] = offset
                    for item in deleted_tree.get_children():
                        deleted_tree.delete(item)
                    for item in result['candidates']:
                        condition = ('Unallocated (tentative)' if item['eligible']
                                     else 'Reallocated / unavailable')
                        deleted_tree.insert('', 'end', iid=item['id'], values=(
                            item['name_hint'], f"{item['size_bytes']:,} B", condition, item['id']))
                    candidate_status.set(
                        f"{result['candidates_found']} entries · {result['eligible_count']} candidates. "
                        'Shift/Ctrl-click to select; no data is written during preview. '
                        + ('CATALOG TRUNCATED at its safety limit.' if result.get('truncated') else ''))
                elif kind == 'offline_devices':
                    offline_inventory.clear()
                    offline_inventory.update({d.id: d for d in value})
                    offline_selected.set('No offline whole disk selected')
                    for item in offline_tree.get_children():
                        offline_tree.delete(item)
                    for device in value:
                        info = device.public()
                        offline_tree.insert('', 'end', iid=device.id, values=(
                            device.model, f'{device.size_bytes / 10**9:.2f} GB',
                            device.bus, info['serial_suffix'], info['identity_hint'], device.id))
                    status.set(f'Found {len(value)} Linux whole disk(s), including internal')
                elif kind == 'prerequisites':
                    tools = value
                    if tools.get('smart_health_available'):
                        prerequisite_text.set('SMART tools ready · Core scanning works without optional forensic tools')
                        prereq_install.configure(state='disabled')
                        prereq_install.pack_forget()
                    else:
                        prerequisite_text.set('SMART not installed · Health checks limited; recovery still available')
                        prereq_install.configure(state=('normal' if tools.get('install_support') == 'winget'
                                                         else 'disabled'))
                        if not prereq_install.winfo_manager():
                            prereq_install.pack(side='right')
                elif kind == 'smartctl_install':
                    prerequisite_text.set('SMART installation finished; rechecking…')
                    check_prerequisites()
                elif kind == 'prerequisite_error':
                    prerequisite_text.set('SMART tool setup requires attention · See Advanced details')
                    write('SMART prerequisite check: ' + str(value) + '\n')
                elif kind == "devices":
                    inventory.clear()
                    inventory.update({d.id: d for d in value})
                    selected.set("No external drive selected")
                    for item in tree.get_children():
                        tree.delete(item)
                    for device in value:
                        public = device.public()
                        tree.insert("", "end", iid=device.id, values=(
                            device.id, device.model, f"{device.size_bytes / 10**9:.2f} GB",
                            device.bus, public["serial_suffix"],
                            public["location"], public["identity_hint"],
                        ))
                        if stats["size"] == 0 and tree.selection() == ():
                            pass
                    status.set(f"Found {len(value)} external whole disk(s)")
                elif kind == 'job_result':
                    if isinstance(value, dict):
                        last_result = value
                        if value.get('status') in {'manifest_created_unattested', 'matches_unattested_manifest',
                                                   'integrity_mismatch', 'incomplete_unknown_regions',
                                                   'verified_restored_copy', 'incomplete_unverified_copy'}:
                            integrity_summary.set(
                                f"Integrity: {value.get('status')} · "
                                f"{value.get('hash_mismatched_chunks', value.get('replaced_chunks', 0))} "
                                f"mismatched/replaced chunks · "
                                f"{value.get('unknown_chunks', value.get('unverified_chunks', 0))} unknown. "
                                "See Advanced Details / export report for exact offsets."
                            )
                elif kind == "done":
                    title, code = value
                    process = None
                    busy = False
                    cancel_button.configure(text='Start job', command=launch_pending, state='disabled')
                    phase_var.set("COMPLETED / REVIEW RESULTS" if code == 0 else f"STOPPED / ERROR {code}")
                    incomplete = bool(last_result and last_result.get('status') in {
                        'completed_with_missing_data', 'in_progress', 'retry_in_progress',
                        'completed_with_skips_or_verify_failures',
                    })
                    if incomplete:
                        phase_var.set('INCOMPLETE IMAGE — FOLLOW-UP NEEDED')
                    elif code == 0 and rescue_metrics.last_event.get('workflow') == 'rescue':
                        eta_var.set('Complete')
                    if rescue_metrics.last_event.get('workflow') == 'rescue':
                        v = rescue_metrics.last_event
                        elapsed = float(v.get('elapsed_seconds') or 0)
                        if elapsed > 0 and int(v.get('recovered_bytes') or 0) > 0:
                            speed_var.set(f"{fmt_bytes(int(int(v['recovered_bytes']) / elapsed))}/s avg")
                    job_status = str((last_result or {}).get('status') or '')
                    title_l = str(title).lower()
                    scan_statuses = job_status.startswith('completed_with_') or job_status in {
                        'stopped_by_user', 'completed',
                    }
                    is_scan = (
                        'diagnosis' in title_l
                        or ('scan' in title_l and 'repair' not in title_l and 'refresh' not in title_l)
                        or ('surface_coverage_pct' in (last_result or {}) and scan_statuses)
                    )
                    is_refresh = 'refresh' in title_l or 'in-place repair' in title_l
                    coverage = (last_result or {}).get('surface_coverage_pct')
                    coverage_txt = (
                        f" Measured coverage ≈ {float(coverage):.1f}%."
                        if isinstance(coverage, (int, float)) else ''
                    )
                    if incomplete and is_scan:
                        warning_var.set(
                            f'SCAN INCOMPLETE ({job_status or "unknown"}): findings may be partial.'
                            f'{coverage_txt} This was diagnosis only — no recovery journal applies.'
                        )
                        warning_label.configure(fg=C['warn'])
                    elif incomplete:
                        warning_var.set(
                            'INCOMPLETE IMAGE: some areas remain missing or unverified. Keep the recovery journal.'
                        )
                        warning_label.configure(fg=C['warn'])
                    elif 'targeted refresh' in str(title).lower() or 'targeted in-place repair' in str(title).lower():
                        outcome = (last_result or {}).get('status', 'unknown')
                        plan = (last_result or {}).get('repair_plan') or {}
                        if outcome == 'completed_targeted_refresh':
                            repaired = ((last_result or {}).get('repair') or {}).get('verified_bytes', 0)
                            warning_var.set(f'Targeted refresh verified {fmt_bytes(int(repaired))}. '
                                            'Data correctness and hardware lifespan are NOT certified.')
                            warning_label.configure(fg=C['ok'])
                        elif outcome == 'partial_repair_unresolved_data':
                            repair_data = (last_result or {}).get('repair') or {}
                            warning_var.set(
                                f"Partial repair: {fmt_bytes(int(repair_data.get('verified_bytes') or 0))} "
                                'rewritten and read-back verified. Some original error regions remain UNKNOWN; '
                                'no replacement data was invented. Use Rescue or review the report.'
                            )
                            phase_var.set('PARTIAL REPAIR — UNRESOLVED ERRORS')
                            warning_label.configure(fg=C['warn'])
                        elif outcome == 'recovery_required':
                            phase_var.set('RECOVERY REQUIRED — ERROR REGIONS ISOLATED')
                            warning_var.set('Read-error budget reached or no repeatable regions could be repaired. '
                                            'Unknown bytes were NOT overwritten. Review the failed offsets, '
                                            'then choose image rescue or separately authorized destructive sector reinitialization.')
                            warning_label.configure(fg=C['warn'])
                        elif outcome == 'completed_no_refresh_needed':
                            warning_var.set('No safe slow-region candidates detected. Nothing was rewritten; '
                                            'a passing scan does not prove file integrity.')
                            warning_label.configure(fg=C['muted'])
                        else:
                            reasons = '; '.join(plan.get('reasons') or [])
                            warning_var.set('Repair was not performed or was incomplete. '
                                            + (reasons or 'Keep the journal and review the report.'))
                            warning_label.configure(fg=C['warn'])
                    elif code != 0 and is_scan:
                        phase_var.set('READ ERRORS FOUND — NEXT STEP: REPAIR / RESCUE')
                        warning_var.set('Scan stopped after significant read/access errors. '
                                        'This does NOT mean any sectors were repaired. '
                                        'Check the error report, USB power/cable and SMART; '
                                        'do not automatically rewrite unknown bytes.')
                        warning_label.configure(fg=C['warn'])
                    elif code == 0 and is_scan:
                        eta_var.set('Complete')
                        readiness = (last_result or {}).get('repair_readiness') or {}
                        blockers = readiness.get('blockers') or []
                        health = (last_result or {}).get('health') or {}
                        findings = job_status.startswith('completed_with_')
                        warning_var.set(
                            (
                                f'SCAN COMPLETE WITH FINDINGS ({job_status}).{coverage_txt} '
                                if findings else
                                f'SCAN COMPLETE — no rewrite performed.{coverage_txt} '
                            )
                            + 'Read-only diagnosis is not Quick Repair (10% guided rewrite) '
                            'and is not Full Repair. Next: Rescue to a separate healthy image, '
                            'or an explicitly acknowledged in-place repair. '
                            + (
                                'Blocked for repair triage: ' + '; '.join(blockers[:2])
                                if blockers else
                                f"Triage health media={health.get('media', '?')} "
                                f"transport={health.get('transport', '?')} "
                                f"mechanical*={health.get('mechanical', '?')}."
                            )
                        )
                        warning_label.configure(fg=C['warn'] if blockers or findings else C['muted'])
                    elif code == 0 and is_refresh:
                        warning_var.set(
                            'Refresh finished. Readback match is not restored lifespan; keep backups.'
                        )
                        warning_label.configure(fg=C['muted'])
                    elif code == 0:
                        warning_var.set(
                            'Job finished. Verify recovered data before relying on the image.'
                        )
                        warning_label.configure(fg=C['muted'])
                    else:
                        warning_var.set(
                            'Job stopped or failed. Preserve the image and recovery journal for resume.'
                        )
                        warning_label.configure(fg=C['fail'])
                    if code != 0 and is_scan:
                        status.set(f'{title}: stopped at read-error safety limit — choose Quick repair or Rescue')
                    elif last_result and last_result.get('status') in {'recovery_required', 'partial_repair_unresolved_data'}:
                        status.set(f"{title}: {last_result['status'].replace('_', ' ')} — review the report")
                    else:
                        status.set(f"{title}: {'finished — review results' if code == 0 else f'exited {code} — journal may support resume'}")
                    if last_result and last_result.get('status') in {
                        'manifest_created_unattested', 'matches_unattested_manifest',
                        'integrity_mismatch', 'incomplete_unknown_regions',
                        'verified_restored_copy', 'incomplete_unverified_copy',
                    }:
                        finding = last_result['status']
                        messages = {
                            'manifest_created_unattested': ('BASELINE CREATED / NOT TRUSTED',
                                'Baseline saved. A checksum of already-corrupt data does not reveal original bytes.'),
                            'matches_unattested_manifest': ('MATCHES REFERENCE HASHES',
                                'All chunks match the baseline. This is NOT proof the baseline was originally correct.'),
                            'integrity_mismatch': ('INTEGRITY ALERT — CHANGED CHUNKS',
                                'Some regions differ from the baseline. They may be corrupt OR legitimate changes; inspect offsets.'),
                            'incomplete_unknown_regions': ('INTEGRITY UNKNOWN — RESCUE GAPS',
                                'Unvisited or unreadable regions remain UNKNOWN, not corrected.'),
                            'verified_restored_copy': ('NEW VERIFIED COPY CREATED',
                                'New image matches the provided reference hashes. Original image is untouched.'),
                            'incomplete_unverified_copy': ('NEW COPY INCOMPLETE / UNVERIFIED',
                                'Some chunks lack trusted replacement bytes. Do not use this copy as fully restored.'),
                        }
                        headline, description = messages[finding]
                        pbar['value'] = 1000
                        metric_var.set('Completed integrity operation')
                        phase_var.set(headline)
                        warning_var.set(description)
                        warning_label.configure(fg=C['warn'] if finding in {
                            'integrity_mismatch', 'incomplete_unknown_regions',
                            'incomplete_unverified_copy'} else C['muted'])
                        for label, text in zip(summary_labels,
                                               ('HASH-MATCHED CHUNKS', 'DIFFERENT / UNVERIFIED CHUNKS',
                                                'OPERATION', 'STATUS')):
                            label.configure(text=text)
                        total_chunks = last_result.get('total_chunks')
                        if type(total_chunks) is int and total_chunks > 0:
                            mismatch_indices = {r['index'] for r in last_result.get('mismatched_regions', [])}
                            unknown_indices = {r['index'] for r in last_result.get('unknown_regions', [])}
                            for i in range(len(map_cells)):
                                j = min(total_chunks - 1, i * total_chunks // len(map_cells))
                                map_cells[i] = ('X' if j in mismatch_indices else
                                                '?' if j in unknown_indices else 'o')
                            map_dirty = True
                            legend_var.set('Integrity chunks · o matched reference  X differs  ? unknown; not a health map')
                        recovered_var.set(str(last_result.get('hash_matched_chunks', '—')))
                        errors_var.set(str(last_result.get('hash_mismatched_chunks',
                                                   last_result.get('unverified_chunks', 0))))
                        speed_var.set('Reference hash comparison')
                        eta_var.set('Complete')
                        status.set(f'{title}: findings ready — inspect the integrity page or save report')
                    write(f"--- Finished: exit code {code} ---\n")
                    redraw_map(force=True)
        except queue.Empty:
            pass
        redraw_map()
        poll_after_id = root.after(100, poll)

    def on_close() -> None:
        if process is not None and process.poll() is None:
            # Never close the UI by killing an in-flight patient write. Even a
            # cooperative STOP needs time for the active read/write to finish.
            messagebox.showinfo('Job still active',
                'Stop the job first and wait for the engine result before exiting. '
                'Do not disconnect a device during a journaled transaction.')
            return
        if poll_after_id is not None:
            try:
                root.after_cancel(poll_after_id)
            except tk.TclError:
                pass
        root.destroy()

    def report_ui_error(error_type, error_value, error_tb) -> None:
        import traceback
        details = ''.join(traceback.format_exception(error_type, error_value, error_tb))
        write('Unexpected interface error:\n' + details + '\n')
        if debug_log_path is not None:
            advanced_open.set(True)
            show_advanced()
        status.set('Interface error — see Advanced details / engine log')
        try:
            messagebox.showerror('DriveRepair interface error',
                                 f'{error_value}\n\nSee Advanced details for troubleshooting.')
        except tk.TclError:
            pass

    root.report_callback_exception = report_ui_error
    if debug_log_path is not None:
        write(f'Debug tracking ON — mirroring engine/UI output to:\n  {debug_log_path}\n')
        status.set('Debug logging available in Advanced Details · Choose a workflow to begin')
    # The recovery dashboard is available on demand but initially hidden so
    # the goal buttons and drive controls fit on normal laptop displays.
    set_dashboard_visible(bool(prefs["dashboard"]))
    root.protocol("WM_DELETE_WINDOW", on_close)
    canvas.bind("<Configure>", lambda e: redraw_map(force=True))
    poll()
    check_prerequisites()
    refresh_devices()
    root.mainloop()
