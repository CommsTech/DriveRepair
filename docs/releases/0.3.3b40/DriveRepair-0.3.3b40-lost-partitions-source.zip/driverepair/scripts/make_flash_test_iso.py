#!/usr/bin/env python3
"""Build a marker-valid DriveRepair-Live hybrid ISO for USB flash UX testing.

This is NOT a Debian live-build recovery OS and is NOT BIOS/UEFI qualified.
Replace with scripts/build_live_iso.sh output before claiming bootability.
"""
from __future__ import annotations

import hashlib
import json
import os
import struct
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]


def main() -> int:
    out_dirs = [
        REPO / 'dist' / 'images',
        REPO / 'dist-live',
        Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData' / 'Local')))
        / 'DriveRepair' / 'images',
    ]
    for directory in out_dirs:
        directory.mkdir(parents=True, exist_ok=True)

    size = 32 * 1024 * 1024
    sector = 2048
    data = bytearray(size)
    data[510:512] = b'\x55\xaa'
    note = b'DRIVEREPAIR LIVE HYBRID PLACEHOLDER - BOOT UNVERIFIED\x00'
    data[0:len(note)] = note

    pvd = 16 * sector
    data[pvd] = 1
    data[pvd + 1:pvd + 6] = b'CD001'
    data[pvd + 6] = 1
    vol = b'DRIVEREPAIR_LIVE'
    data[pvd + 40:pvd + 40 + len(vol)] = vol
    nsect = size // sector
    data[pvd + 80:pvd + 84] = struct.pack('<I', nsect)
    data[pvd + 84:pvd + 88] = struct.pack('>I', nsect)

    manifest = {
        'name': 'DriveRepair-Live-amd64',
        'status': 'ENGINEERING_FLASH_TEST_IMAGE',
        'boot': 'UNVERIFIED',
        'built_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'note': (
            'Valid hybrid markers for USB flash/readback testing only. '
            'Not a Debian live-build recovery OS. Replace with '
            'scripts/build_live_iso.sh output before boot qualification.'
        ),
    }
    payload = json.dumps(manifest, indent=2).encode()
    off = 32 * sector
    data[off:off + len(payload)] = payload

    iso_path = out_dirs[0] / 'DriveRepair-Live-amd64.iso'
    iso_path.write_bytes(data)
    sha = hashlib.sha256(data).hexdigest()
    iso_path.with_suffix('.iso.sha256').write_text(
        f'{sha}  {iso_path.name}\n', encoding='ascii'
    )
    for directory in out_dirs[1:]:
        target = directory / iso_path.name
        target.write_bytes(data)
        target.with_suffix('.iso.sha256').write_text(
            f'{sha}  {target.name}\n', encoding='ascii'
        )

    sys.path.insert(0, str(REPO / 'desktop'))
    from driverepair_desktop.recovery_media_catalog import find_local_recovery_iso
    from driverepair_desktop.usb_flash import inspect_hybrid_iso

    info = inspect_hybrid_iso(iso_path)
    found = find_local_recovery_iso(search_roots=out_dirs)
    print(f'ISO {iso_path}')
    print(f'bytes {size}')
    print(f'sha256 {sha}')
    print(f'inspect {info}')
    print(f'catalog {found}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
